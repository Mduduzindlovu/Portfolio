<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="homepage.css">
    <title>Reports for Manager</title>
</head>
<body>
     <!--Icons at the top of the page-->
<div class="icon-bar">
    <a href="managerhomepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="90px" height="90px"></a>
  </div>
  <div class="header">
    <h1 style="font-family: arial;">Wood Street Academy</h1>
  </div>
  <div class="navbar">
  <a href="managergeneratereports.php">Generate Reports</a>
    <a href="managerpartsordered.php">Ordered Parts</a>
    <a href="managerstatus.php">Current status of Repair Jobs</a>
    <a href="partsonhand.php">Total amount of parts on hand</a>
    <a href="completed.php">Repairs history</a>
    <a href="managerlogout.php">Logout</a>
  </div>
  </div>
  </div> 
    
<h1>Please select a report to display</h1>
<input type="radio" name="fav_language" id="idparts" onclick="window.location='managerpartsordered.php'">
<label for="parts" name="parts">Ordered parts</label><br>
<input type="radio" name="fav_language" id="idstatus" onclick="window.location='managerstatus.php'">
<label for="status" name="status">Status of repair job</label><br>
<input type="radio" name="fav_language" id="idrepairs">
<label for="repairs" name="repairs" id="repairs">Repair costs summary</label><br>
<input type="radio" name="fav_language" id="idtotal"  onclick="window.location='partsonhand.php'">
<label for="total" name="total" id="idtotal">Total amount of parts on hand</label><br>
<input type="radio" name="fav_language" id="idhistory">
<label for="history" name="history" id="idhistory">Repairs history</label><br>
</body>

<?php
 require_once("config.php");
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to the database");
if(isset($_REQUEST['total'])){
    header("Location:partsonhand.php");
}

?>
</html>