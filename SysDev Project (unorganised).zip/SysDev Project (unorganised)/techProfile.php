<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Update information html page. </title>
</head>

<style>
    * {
        box-sizing: border-box;
    }

    body {
        font-family: Arial;
        padding: 10px;
        background: #f1f1f1;
    }

    .registerbody {
        text-align: center;
        background-color: white;
        padding-bottom: 10px;

    }

    /* Header*/
    .header {
        padding: 10px;
        margin-top: 17px;
        text-align: center;
        background: #b4a7d6;
        color: black;
        width: 100%;

    }

    /* Style the top navigation bar */
    .navbar {
        overflow: hidden;
        background-color: #89C;
        width: 100%;
        display: flex;
        justify-content: space-between;
    }

    /* Style the navigation bar links */
    .navbar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
    }

    /* Right-aligned link */
    .navbar a.right {
        float: right;
    }

    /* Change color on hover */
    .navbar a:hover {
        background-color: #89CF;
        color: black;
    }

    /* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
    @media screen and (max-width: 400px) {
        .navbar a {
            float: none;
            width: 100%;
        }
    }

    /* styling for the icons at the top*/
    body {
        margin: 0;
    }

    .icon-bar {
        width: 100%;
        background-color: #b4a7d6;
        overflow: auto;
        position: fixed;
        display: flex;
        justify-content: space-around;
    }


    .icon-items {
        display: flex;
        justify-content: space-between;
        width: 500px;
    }

    .icon-bar a {
        float: right;
        width: 12%;
        text-align: center;
        padding: 9px 0;
        transition: all 0.3s ease;
        color: white;
        font-size: 21px;
    }

    .icon-bar a.split {
        float: left;
    }

    .icon-bar a:hover {
        background-color: #89Cf;
    }

    /* Footer */
    .footer {
        padding: 10px;
        align-content: center;
        background: #89C;
        border-radius: 5px;
    }

    /* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
    @media screen and (max-width: 700px) {
        .row {
            flex-direction: column;
        }
    }

    /* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
    @media screen and (max-width: 400px) {
        .navbar a {
            float: none;
            width: 100%;
        }
    }

    .active {
        background-color: #89Cf;
    }

    /*css for the footer */
    .repairs {
        width: 250px;
        float: left;

    }

    .repairs a {
        background-color: #89C;
        color: black;
        display: block;
        padding: 12px;
        text-decoration: none;
    }

    .repairs a:hover {
        background-color: #89C;
        color: white;
    }

    .repairs a.active {
        background-color: #89C;
        color: white;
    }

    .policies {
        width: 250px;
        float: left;

    }

    .policies a {
        background-color: #89C;
        color: black;
        display: block;
        padding: 12px;
        text-decoration: none;
    }

    .policies a:hover {
        background-color: #89C;
        color: white;
    }

    .policies a.active {
        background-color: #89C;
        color: white;
    }

    .aboutus {
        width: 250px;
        float: left;

    }

    .aboutus a {
        background-color: #89C;
        color: black;
        display: block;
        padding: 12px;
        text-decoration: none;
    }

    .aboutus a:hover {
        background-color: #89C;
        color: white;
    }

    .aboutus a.active {
        background-color: #89C;
        color: white;
    }

    .chatwithus {
        width: 250px;
        float: left;

    }

    .chatwithus a {
        background-color: #89C;
        color: black;
        display: block;
        padding: 12px;
        text-decoration: none;
    }

    .chatwithus a:hover {
        background-color: #89C;
        color: white;
    }

    .chatwithus a.active {
        background-color: #89C;
        color: white;
    }

    .footer1 {
        background-color: #89C;
        height: 200px;
        padding: 10px;


    }

    .footer2 {
        background-color: #89C;
        height: 50px;
    }

    .copyrightsentence {
        float: left;
    }

    .footer-content {
        margin-left: 20%;
    }
</style>

<body>
    <!--Icons at the top of the page-->
    <div class="icon-bar">
        <div class="hangburger">
            <a href="#" class="split"><i class="fa fa-bars"></i></a>
        </div>
        <div class="icon-items">
            <a href="#"><i class="fa fa-question-circle-o"></i></a>
            <a href="#"><i class="fa fa-envelope"></i></a>
            <a href="#"><i class="fa fa-bell-o"></i></a>
            <a href="#"><i class="fa fa-user-o"></i></a>
            <a href="Homepage.html"><i class="fa fa-home"></i></a>
            <a href="#" class="split"><i class="fa fa-bars"></i></a>
        </div>

    </div>


    <div class="header">
        <h1>Wood Street Academy</h1>
        <!--search bar-->
        <form class="example" action="add.php">
            <!-- <input type="text" placeholder="Search.." name="search">-->
            <!--<button type="submit"><i class="fa fa-search"></i></button>-->
        </form>
    </div>

    <div class="navbar">
        <a href="Technicianhomepage.php">Home</a>
        <a href="updateTechStatus.php">Progress Status</a>
        <a href="aboutus.html">About us</a>
        <a href="logout.php">Logout</a>
    </div>
    <?php ?>

    <!--This is is a whole webpage-->
    <div class="registerbody">
    <?php
        $_SESSION['username']; ?>
              
        <h1>Welcome Back <?php echo "{$_SESSION['username']}" ?></h1>

        <?php
        require_once("config.php");
        $name = $_SESSION['username'];
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");

        $query = "SELECT * FROM fantasticfour.technician WHERE Username = '$name'";
        $result =mysqli_query($conn,$query) or die("could not retrieve data".$conn ->error);

        while($row = mysqli_fetch_array($result))
        {
          
          echo"
          <form action=\"techprofileUpdate.php\" method=\"post\">
          <label for=\"Firstname\"><b>Firstname</b></label><br>
          <input type=\"text\" value=\"{$row['Firstname']}\" id=\"Fname\" name=\"Fname\" required><br><br>
            
          <label for=\"Lastname\"><b>Lastname</b></label><br>
          <input type=\"text\" value=\"{$row['Lastname']}\" id=\"Lname\" name=\"Lname\" required><br><br>

          <label for=\"Username\"><b>Username</b></label><br>
          <input type=\"text\" value=\"{$row['Username']}\" id=\"Uname\" name=\"username\" required><br><br>

          <label for=\"Email\"><b>Email</b></label><br>
          <input type=\"email\" value=\"{$row['Email']}\" id=\"Email\" name=\"Email\" required><br><br>

          <label for=\"Psw\"><b>Password</b></label><br>
          <input type=\"password\" id=\"Password\" value=\"{$row['Password']}\" name=\"Password\" pattern=\"[x][0-9]{4}\"
              required><br><br>
          
          <input type=\"hidden\" name=\"techID\" id=\"techID\" value=\"{$row['technicianCode']}\">
          <input type=\"submit\" value=\"Update\" size=\"30\" ><br>
          </form>
          ";
         
         } 
        


        
        ?>

      </div>


    <div class="footer1">
        <div class="footer-content">
            <div class="repairs">
                <a href="#">Repairs</a>
                <a href="#">Link 2</a>
                <a href="#">Link 3</a>
                <a href="#">Link 4</a>
            </div>
            <div class="policies">
                <a href="#">Policies</a>
                <a href="#">Link 2</a>
                <a href="#">Link 3</a>
                <a href="#">Link 4</a>
            </div>
            <div class="aboutus">
                <a href="#">About us</a>
                <a href="#">Link 2</a>
                <a href="#">Link 3</a>
                <a href="#">Link 4</a>
            </div>
            <div class="chatwithus">
                <a href="#">Chat with us</a>
                <a href="#">Link 2</a>
                <a href="#">Link 3</a>
                <a href="#">Link 4</a>
            </div>
        </div>

    </div>
    <div class="footer2">
        <div class="copyrightsentence">
            <small><i class="fa fa-copyright"></i>
                2022. All Rights Reserved. Proudly created by Fantastic Four.
                <a href="termsandpolicies">Terms and Policies</a>
                Last modified: 24 August 2022</small>
        </div>
    </div>

</body>

</html>