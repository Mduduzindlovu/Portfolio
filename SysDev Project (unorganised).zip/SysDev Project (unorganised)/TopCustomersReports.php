<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="TopCustomersReports.php" method="POST">
    <p>Please select a report:</select></p>
    <input type="radio"  name="report" id="TopCustomer" value="TopCustomer">
    <label for="TopCustomer"><strong>Top Customers</strong></label><br>

    <input type="radio" name="report" id="TopDevices" value="TopDevices" >
    <label for="TopDevices"><strong>Top desktop/laptop </strong></label><br> 
    <br>
    <input type="submit" name="submit" value="Generate Report">
    </form>
    <br>

    <?php
    if (isset($_REQUEST['submit'])){

      $reportChosen = $_REQUEST['report'];

      require_once("config.php");

    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");

    if ($reportChosen == "TopCustomer"){
        $query33="SELECT customerCode,deviceName,COUNT(computerCode)
                    FROM fantasticfour.computers 
                    GROUP BY customerCode
                    ORDER BY COUNT(computerCode) DESC";

          $result100 = mysqli_query($conn,$query33) or die("Could not retrive the data!");

          echo "<h2>Top Customers</h2>
          <table>
                  <tr bgcolor=\"#428bca\">
                  <th>Customers Code</th>
                  <th>Device Name</th>
                  <th>Number of count(Customer Code)</th>
                  </tr>";
          

           while($row=mysqli_fetch_array($result100)){
            echo "<tr>";
            echo "<td>{$row['customerCode']}</td>";
            echo "<td>{$row['deviceName']}</td>";
            echo "<td>{$row['COUNT(computerCode)']}</td>";
            echo "</tr>";
          }
          echo "</table>";

        }elseif($reportChosen == "TopDevices"){
              echo "<p> Reports still needs to be implemented</p>"; 
          }
          mysqli_close($conn);
        }
          ?> 
</body>
</html>