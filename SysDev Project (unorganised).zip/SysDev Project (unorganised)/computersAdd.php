<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $deviceName = $_REQUEST['deviceName'];
   /*  $model = $_REQUEST['model'];
    $customerID= $_REQUEST['customerId']; */
    //adding constants from database
    require_once("config.php");
    // add the database credentials 
    // make connection to database 
    $conn = mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE)
    or die ("<h3><p style = \"color: red\"> Could not connect to the database!</p></h3>");
    // issue query instructions e
    $q = "SELECT custormerCode from customer where customer.custormerCode=41";
    $result = mysqli_query($conn,$q) or die ("<h3><p style =\" color:red\"> Could not find the customer </p></h3>");
   
    $CustomersID = 0;
    while($row = mysqli_fetch_array($result)){
        $CustomersID=$row['custormerCode'];
       }
    echo " $CustomersID";
    echo " $deviceName";


    $query = "INSERT INTO fantasticfour.computers (custormerCode,Name) 
                VALUES('$CustomersID','$deviceName')";

    $result = mysqli_query($conn,$query) or die ("<h3><p style =\" color:red\"> Could not add computer </p></h3>");
    // close the connection to database 
    mysqli_close($conn);
    // display message to confirm the data was instered 
    echo "<h3> The new computer was added! </h3>";

    ?>
</body>
</html>