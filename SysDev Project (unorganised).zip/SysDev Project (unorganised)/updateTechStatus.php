<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php

session_start();
  require_once("config.php");

    if(isset($_REQUEST['complete'])){

        $repcode= $_REQUEST['repCode'];
  
   // $optradio = $_REQUEST['optradio'];

    $status=100;

  $conn= mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or die("die");

  $query = "UPDATE repair_job  SET StatusOfrepair = '$status' WHERE repJB_code = '$repcode'" or die ("die");

  $result = mysqli_query($conn,$query);

 

mysqli_close($conn);

$time=0.5; // seconds to wait 
sleep($time);

echo "<script> Repair Job Code:&nbsp" .$repcode. "&nbspwas successfully updated! </script>";
    
  }
?>
<script></script>
</body>
</html>