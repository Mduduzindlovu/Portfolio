<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $NameOfPart= $_REQUEST['nameofpart'];
    $TechnicianCode= $_REQUEST['TechnicianCode'];

    require_once("config.php");
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");

    // $CustomersID = 0;
    // while($row = mysqli_fetch_array($res)){
    //     $CustomersID=$row['custormerCode'];
    //    }
    $query = "UPDATE fantasticfour.orderparts SET NameOfPart ='$NameOfPart'
                    WHERE technicianCode = $TechnicianCode";
    $result = mysqli_query($conn, $query) or die("qUERY1" . $conn->error);

    mysqli_close($conn);

    echo "<script>alert(\" Your profile has been Updated Successfully\");
    window.location.href= \"techjobs.php\";
    
    </script>";

    
    //$result2 = mysqli_query($conn,$query2) or die("QUERY!")

    ?>
</body>

</html>