<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="homepage.css">
    <title>Parts on hand</title>
</head>
<body>
          <!--Icons at the top of the page-->
  <div class="icon-bar">
    <a href="managerhomepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="90px" height="90px"></a>
  </div>
  <div class="header">
    <h1 style="font-family: arial;">Wood Street Academy</h1>
  </div>
  <div class="navbar">
  <a href="managergeneratereports.php">Generate Reports</a>
    <a href="managerpartsordered.php">Ordered Parts</a>
    <a href="managerstatus.php">Current status of Repair Jobs</a>
    <a href="partsonhand.php">Total amount of parts on hand</a>
    <a href="completed.php">Repairs history</a>
    <a href="managerlogout.php">Logout</a>
  </div>
  </div>
  </div>
<?php
 require_once("config.php");
 $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not establish a connection");

$query= "SELECT * FROM fantasticfour.brandnames ";
$results=mysqli_query($conn,$query) or die("could not get the brand ID");
$name = "";
$quantity=0;
$price=0;
$product= 0;
while($row=mysqli_fetch_array($results)){
    $name=$row['nameofparts'];
    $quantity=$row['Quantity'];
    $price=$row['Prices'];
    $product = $price*$quantity;

    
$query2= "SELECT count(NameOfPart) as total from orderparts where NameOfPart='$name' ";
$results2=mysqli_query($conn,$query2) or die("could not get the brand ID");
$number= 0;
$totals=0;
while($row=mysqli_fetch_array($results2)){
    $number=$row['total'];
}
$totals =$number*$price;
    echo"<div class=\"container\">
    <h2>$name</h2>
    <h4>Total Inventory Quantity : $quantity</h4>
    <h5>Allocated Inventory Quantity :R{$totals} </h5>
    <h5>Available Inventory Quantity : R{$product} </h5>
    </div>";


}
    ?>
    <style>
      h2 {text-align: center;}
      h4 {text-align: center;}
      h5 {text-align: center;}

    .container{
    display: flex;
    
    justify-content: space-around;
    flex-direction: column;
    border: 1px ;
  padding: 10px;
  box-shadow: 5px 8px #edebeb;
  margin-top: 20px;
}
    </style>
</body>
</html>