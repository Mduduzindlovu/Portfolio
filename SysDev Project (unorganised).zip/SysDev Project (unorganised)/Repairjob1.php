<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    table,
    th,
    td {
        border: 1px solid black;
        border-collapse: collapse;
    }

    th,
    td {
        padding-top: 10px;
        padding-bottom: 20px;
        padding-left: 30px;
        padding-right: 40px;
    };
    </style>
</head>

<body>
    <!-- <form action="repairJob.php" method="POST"> -->
    <?php


    require_once("config.php");


    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");
    $query = "SELECT repJB_code FROM fantasticfour.repair_job ";
    $result = mysqli_query($conn, $query) or die("could not retrieve date");
    echo "<h1 style=\"text-align:center\">List of the assigned jobs</h1>";
    echo "<table style=\"border-spacing: 20px;\">";
    echo "<tr>
            <th>Repair Job code</th>
            
            <th>Edit job description</th>
            <th>Update status</th>
            <th>Delete job</th>
        </tr>";
    while ($row = mysqli_fetch_array($result)) {
        echo " <tr>";
        echo "
            <td>{$row['repJB_code']}</td>
            <td><a href=\"REPAIRJOBedit.php?id={$row['repJB_code']}\"><input type=\"submit\" value=\"Edit\"> </a></td>
            <td> <input type=\"submit\" value=\"Update\"> </td>
            <td><a href=\"REPAIRJOBdelete.php?id={$row['repJB_code']}\"" . "onClick=\"return confirm('Are you sure you want to delete " .  "the job with ID ".($row['repJB_code']). "?"."');\"><input type=\"submit\" value=\"Delete\"></a></td>
            <input type=\"hidden\" name=\"repCode\" value=\"< {$row['repJB_code']} \">";

   echo "</tr> ";
    }
    echo  "</table>";
    ?>

    <!-- </form> -->

    <!-- <td> -->

    <!--  <select name=\"repairjobtypes\" id=\"Repairtypes\">
                    <option value=\"hardware\">Hardware</option>
                    <option value=\"software\">Software</option>
                    <option value=\"peripherals\">Peripherals</option>
                </select>
            </td> -->
 

</html>