<?php

if ($devName == "Acer" && $problem == "Screen repair") {
    echo "Price is R5000";
    }
    elseif ($devName== "Lenovo" && $problem == "Screen repair") {
    echo "Price is R4500";
    }
    elseif ($devName== "Apple" && $problem == "Screen repair") {
    echo "Price is R5500"; 
    }
    elseif ($devName== "Asus" && $problem == "Screen repair") {
    echo "Price is R5000";
    }
    elseif ($devName== "HP" && $problem == "Screen repair") {
    echo "Price is R5000"; 
    }
    else  {
    echo "Price is R3500";
    }


    if ($devName== "Acer" && $problem == "Battery"){
    echo "Price is R1500";
    }
    elseif ($devName== "Lenovo" && $problem == "Battery"){
    echo "Price is R2000";
    }  
   elseif ($devName== "Apple" && $problem == "Battery"){
    echo "Price is R2500";
    }
    elseif ($devName== "Asus" && $problem == "Battery"){
    echo "Price is R2000";
    }
    elseif ($devName== "HP" && $problem == "Battery"){
     echo "Price is R3000";
    }   
    else {
    echo "Price is R1700";
    }

    if ($devName== "Acer" && $problem == "Keyboard"){
      echo "Price is R500"; 
    }
    elseif ($devName== "Lenovo" && $problem == "Keyboard"){
     echo "Price is R450";
    }
    elseif ($devName== "Apple" && $problem == "Keyboard"){
     echo "Price is R1000";   
    }
    elseif ($devName== "Asus" && $problem == "Keyboard"){
      echo "Price is R650"; 
    }
    elseif ($devName== "HP" && $problem == "Keyboard"){
       echo "Price is R700";
    }
    else {
       echo "Price is R600"; 
    }

    if ($devName== "Acer" && $problem == "Charger"){
       echo "Price is R600"; 
    }
    elseif ($devName== "Lenovo" && $problem == "Charger"){
     echo "Price is R350";
    }
    elseif ($devName== "Apple" && $problem == "Charger"){
    echo "Price is R1500";
    }
    elseif ($devName=="Asus" && $problem == "Charger"){
    echo "Price is R300";
    }
    elseif ($devName== "HP" && $problem == "Charger"){
    echo "Price is R400";
    }
    else {
    echo  "Price is R300";
    }


?>