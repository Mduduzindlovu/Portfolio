<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Repair job code</title>
</head <?php
        session_start();


        $techdescript = $_REQUEST['DescriptionOfthefault'];


        require_once("config.php");

        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("NnOo");

        /*  $repairing = mysqli_query($conn, "SELECT repJB_code FROM fantasticfour.repair_job  WHERE Username = '$username'") or die("Psudofy");
        $row_rsmyQuery1 = mysqli_fetch_assoc($repairing);
        $lungisa = (int)($row_rsmyQuery1['repJB_code']); */

        $handle = mysqli_query($conn, "SELECT repJB_code FROM fantasticfour.repair_job") or die("Phuck");
        $row_rsmyQuery = mysqli_fetch_array($handle);
        $img = $row_rsmyQuery['repJB_code'];


        $query1 = "INSERT INTO fantasticfour.repair_job (DescriptionOfthefault) VALUES ('$techdescript') where repJB_code = $img ";

        $result = mysqli_query($conn, $query1) or die("QUERYYYY" . $conn->error);

        // header("Location:Repairjob.html");

        echo " <div style=\"background-color: Green\">Your description has been added successfully! </div>";

        mysqli_close($conn);














        ?>