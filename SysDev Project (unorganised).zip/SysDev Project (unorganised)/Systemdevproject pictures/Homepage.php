<!DOCTYPE html>
<html lang="en">

<head>
    <title>Wood Street Academy</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="homepage.css">

</head>

<body>
    <!--container for icons, header and navbar-->
    <div class="container1">

        <!--Icons at the top of the page-->
        <div class="icon-bar">
            <a href="#"><i class="fa fa-question-circle-o"></i></a>
            <a href="#"><i class="fa fa-envelope"></i></a>
            <a href="#"><i class="fa fa-bell-o"></i></a>
            <a href="#"><i class="fa fa-user-o"></i>
             <button onclick="location.href='profile.php'"><i class="fa fa-caret-down"></i></button>
                    <br> <?php
                session_start();
                $_SESSION['username'];
                ?>
                    <?php echo "{$_SESSION['username']}" ?>
            </a>

            <a href="Homepage.html"><i class="fa fa-home"></i></a>

            <a href="Homepage.html" class="split"><img src="images HOMEPAGE/Logo.png" width="90px" height="90px"></a>
        </div>
        <div class="header">
            <h1 style="font-family: arial;">Wood Street Academy</h1>
        </div>
        <div class="navbar">
            <a href="MakeABooking.php">Make a booking</a>
            <a href="trackstatus.php">Track status</a>
            <a href="Systemdevproject pictures\General Repair prices.html"> General Repair Prices</a>
            <a href="">Make a Payment</a>
            <a href="aboutus.html">About us</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    <!--added for functional purposes-->
    <div class="main">
        <h2>Welcome to the Wood Street Academy PC Repairs department!</h2>
        <h5>Our friendly staff is excited to help you with all your needs.</h5>
    </div>
    <!--slideshow for header image-->
    <div class="slideshow-container" style="margin-top: 90px">

        <!--images with number and caption text -->
        <div class="mySlides fade">
            <marquee>
                <img src="images HOMEPAGE/laptop.jpg" style="width:100%" height="relative">
            </marquee>
        </div>

        <div class="mySlides fade">
            <img src="images HOMEPAGE/tecjnician.jpg" style="width:100%" height="auto">
        </div>

        <div class="mySlides fade">
            <img src="images HOMEPAGE/students.jpg" style="width:100%" height="auto">
        </div>

        <!-- Next and previous buttons -->
        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>
    </div>
    <br>

    <!-- The dots/circles -->
    <div style="text-align:center">
        <span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
        <span class="dot" onclick="currentSlide(3)"></span>
    </div>
    <div class="main">
        <h1 style="color: #89c;">Welcome to the Wood Street Academy PC Repairs department!</h1>
        <h3>Our friendly staff is excited to help you with all your needs.</h3>

    </div>
    <div class="advert">
        <h3>Why pick our services?</h3>
        <p>The department offers a wide ranges of laptop and desktop services from general maintentance to hardware
            repairs and other repairs as well. The Wood Street Academy PCRepairs deparment prides itselff on the
            efficiency and excellence of the services providend by the department. With the new and improved system that
            has now moved online your computer will be fixed at a fast rate, all at your convenience!</p>
        <p>The department is there to attend to all your computer and laptop needs with a team of highly qualified staff
            ready to help you.Now, we have an online booking system which you can use wherever and whenever. Using our
            services has never been simpler!</p>
        <p> Can't wait to give our amazing services a try? Click the link below which will give in you instant access to
            make your booking
        </p>
        <button onclick="document.location='BOOKING.html'"> Go to Booking</button>
    </div>
    </div>
    <h3 style="font-size: 150%; color:#89C;">Our aim as a department</h3>
    <ul>
        <li> As the new and revamped department we aim to Provide all our clients with magnificent quality products
            whilst ensuring that our prices remain competitive to the advantage of our clients.</li>
        <li> Our aim is to build positive client relations through the provision of value-added services, trnsparency,
            reliability and integrity.</li>
        <li> Equipping our technicians with the necessary training and diagnostic equipment</li>
    </ul>
    <br>
    <h3>What we offer</h3>
    <ul>
        <li>BEST REPAIR PRICES FOR YOUR DEVICE IN TOWN!</li>
        <li>Low prices</li>
        <li>Efficient services</li>
        <li>Highly qualified technicians</li>
    </ul>
    <h2>Services provided by the department</h2>
    <p style="font-style: italic;">*Please note that this list is not exhaustive and we do handle some special cases
        where possible.</p>
    <div class="row">
        <div id="column" style="padding: 30px;">
            <img src="images HOMEPAGE/hardware.jpg" name="Harware" height="130px" style="padding: 30px;">
            <p>Hardware repairs for <br> your laptop or computer</p>
        </div>
        <div class="column" style="padding: 30px;">
            <img src="images HOMEPAGE/software.jpg" name="software" height="130px" style="padding: 30px;">
            <p>Software repairs</p>
        </div>
        <div class="column" style="padding: 30px;">
            <img src="images HOMEPAGE/peripherals.jpg" name="Peripherals" height="130px" style="padding: 20px;">
            <p>Peripheral repairs and <br>we sell accessories as well</p>
        </div>
    </div>
    </div>
    </div>
    <h3>Operating hours</h3>
    <ul>
        <li>We are open 9 AM - 5 PM, Monday to Thursday</li>
        <li>We are open 9 AM - 3:00 PM Friday</li>
        <li>Public Holidays and Weekends- Closed</li>
    </ul>
    <h3>How to get in touch with us</h3>
    <ul>
        <li>Telephone number: 046 654 1212</li>
        <li>Email: <a href="#">pcrepairs@campus.wsa.ac.za</a></li>
    </ul>
    <h3>Where to find us</h3>
    <ul>
        <li>Hamilton Building <br> Prince Alfred Street <br>
            6139, Grahamstown<a
                href="https://www.google.com/maps/dir/-33.3106284,26.5255944/rhodes+university/@-33.3119349,26.5102447,15z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x1e645dd0c6d4fc47:0x9982445ffb8737af!2m2!1d26.5163135!2d-33.3135911">
                Address</a></p>
    </ul>
    <button onclick="topFunction()" id="button" title="top">Top</button>
    </div>
    <div class="footer1">
        <div class="repairs">
            <h5>Repairs</h5>
            <a href="#">General pricing</a>
            <a href="FAQ.html">Frequently asked questions</a>
        </div>
        <div class="policies">
            <h5>Policies<h5>
                    <a href="privacypolicy.html">Privacy policy</a>
                    <a href="Termsandconditions.html">Terms and Conditions</a>
        </div>
        <div class="aboutus">
            <a href="aboutus.html">About us</a>
            <a
                href="https://www.google.com/maps/dir/-33.3106284,26.5255944/rhodes+university/@-33.3119349,26.5102447,15z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x1e645dd0c6d4fc47:0x9982445ffb8737af!2m2!1d26.5163135!2d-33.3135911">Our
                location</a>
        </div>
    </div>
    <div class="footer2">
        <div class="copyrightsentence">
            <small><i class="fa fa-copyright"></i>
                2022. All Rights Reserved. Proudly created by Fantastic Four.
                <a href="termsandpolicies">Terms and Policies</a>
                Last modified: 24 August 2022</small>
        </div>
    </div>
    <script>
    let slideIndex = 1;
    showSlides(slideIndex);

    // Next/previous controls
    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    // Thumbnail image controls
    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("dot");
        if (n > slides.length) {
            slideIndex = 1
        }
        if (n < 1) {
            slideIndex = slides.length
        }
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";
    }
    // to resize the 'header' when you scroll *not working*
    window.onscroll = function() {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
            document.getElementById("container1").style.fontSize = "30px";
        } else {
            document.getElementById("container1").style.fontSize = "90px";
        }
    }
    // automate the slideshow
    let slideIndex1 = 0;
    showSlides();

    function showSlides() {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("dot");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";
        setTimeout(showSlides, 2000); // set to change image every 2 seconds
    }
    //back to top button
    var mybutton = document.getElementById("button");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }

    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
    </script>
</body>

</html>