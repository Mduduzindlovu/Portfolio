<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    table,
    th,
    td {
        border: 1px solid black;
        border-collapse: collapse;
    }

    th,
    td {
        padding-top: 10px;
        padding-bottom: 20px;
        padding-left: 30px;
        padding-right: 40px;
    }
    </style>
</head>

<body>
    <?php
    require_once("config.php");
    

    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");
    $query = "SELECT * FROM fantasticfour.repair_job ";
    $result = mysqli_query($conn, $query) or die("could not retrieve date");

    echo "<form action=\"Repairjob.php\" method=\"post\">";
    echo "
        <table style=\"border-spacing: 20px;\">
        
        <tr>
            <th>RepairJBCode</th>
            <th> Types</th>
            <th>Description</th>
            <th>Job details</th>
            <th>Status</th>
            <th>Delete</th>
        </tr>";
    while ($row = mysqli_fetch_array($result)) {

        echo "<tr>
            <td>{$row['repJB_code']}</td>
            <td>
    
                <!-- <form action=\"RepairJobs.php\"> -->
                <select name=\"repairjobtypes\" id=\"Repairtypes\">
                    <option value=\"hardware\">Hardware</option>
                    <option value=\"software\">Software</option>
                    <option value=\"peripherals\">Peripherals</option>
                </select>
            </td>

            <td><input type=\"text\" name=\"DescriptionOfthefault\" id=\"DescriptionOfthefault\">  </td>
            <td> <input type=\"submit\" value=\"Edit\"> </td>
            <td> <input type=\"submit\" value=\"update\"> </td>
            <td><input type=\"submit\" value=\"x\"></td>
            
    
    
        </tr>";
    }
   echo "</table>";
        
    

    echo "<input type=\"submit\" name=\"submit\">";
    echo "</form>";




    ?>


</body>

</html>