<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
  
    $fname = $_REQUEST['Fname'];
    $lname = $_REQUEST['Lname'];
    $pass  = $_REQUEST['Password'];
    $username = $_REQUEST['username'];
    $email = $_REQUEST['Email'];
    $phoneNumber = $_REQUEST['Phone'];


    require_once("config.php");
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");

    $sql ="SELECT Email FROM fantasticfour.customer WHERE Email= '$email'" ;
    
    $result1 = mysqli_query($conn,$sql) or die("Could not excute Query!");

    if (mysqli_num_rows($result1) > 0){
        echo '<script> alert("Email already exists"); window.location.href=\'login.html\';</script>';
    }else 
    {    header("Location:Homepage.php");
        
    $query = "INSERT INTO fantasticfour.customer (Firstname,Lastname,Username,Email,Password,phoneNumber) 
    VALUES ('$fname','$lname','$username','$email','$pass','$phoneNumber')";

    $result = mysqli_query($conn, $query) or die("qUERY1" . $conn->error);
    //$result2 = mysqli_query($conn,$query2) or die("QUERY!")
    /* $sql ="SELECT Username,Password,customerCode  FROM fantasticfour.customer WHERE Username='$username' AND Password='$pass'";
    $result = mysqli_query($conn,$sql);
    $database_password = "" ;
    $id = 0;
    $username_ = "";
    echo "$database_password";
    while($row = mysqli_fetch_array($result)){
        $database_password= $row['Password'];
        $id = $row['customerCode'];
        $username_ =$row['Username'];
     
    }
    if ($pass==$database_password && $username==$username_ ){
        $_SESSION['id']= $id;
        $_SESSION['username'] = $username;
        header("Location: Homepage.php");
        echo "user exists";
        header("Location:Homepage.php");
    }
 */
   

    mysqli_close($conn);
}




//     $nameofdevice = $_REQUEST['nameofdevice'];
//     $date = $_REQUEST['date'];
//     // $problem = $_REQUEST['problem'];
//     $description = $_REQUEST['description'];
//     $phoneNumber = $_REQUEST['PhoneNumber'];
//     $username = $_REQUEST['name'];

//     require_once("config.php");

//     $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");

//     $handle = mysqli_query($conn, "SELECT customerCode FROM fantasticfour.customer  WHERE Username = '$username'") or die("Phuck");
//     $row_rsmyQuery = mysqli_fetch_assoc($handle);
//     $img = (int)($row_rsmyQuery['customerCode']);


//     $qr = "INSERT INTO fantasticfour.computers (customerCode,deviceName,description,Bookin_date,PhoneNumber) 
//  VALUES ('$img','$nameofdevice','$description','$date',$phoneNumber)";
//     $result = mysqli_query($conn, $qr) or die("qUERY");


//     echo " The successfully orderd!";

//     $qr = "SELECT `computers`.`computerCode`,
//      `computers`.`customerCode`,
//      `computers`.`deviceName`
//  FROM `fantasticfour`.`computers` ORDER BY `computers`.`computerCode` Desc;";
//     $result = mysqli_query($conn, $qr) or die("qUERY" . $conn->error);
//     $row = mysqli_fetch_array($result);
//     $qr = "INSERT INTO `fantasticfour`.`repair job`
//  (`customerCode`,
//  `computerCode`
//  )
//  VALUES
//  ({$row['customerCode']},
//  {$row['computerCode']}
//  );";

//     $result = mysqli_query($conn, $qr) or die("qUERY" . $conn->error);


    
    ?>
</body>

</html>