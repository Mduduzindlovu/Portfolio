<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Wood Street Academy</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="homepage.css">
</head>
<body>
  </style>
</head>

<body>
  <!--container for icons, header and navbar-->
  <div class="container1">
  <!--Icons at the top of the page-->
  <div class="icon-bar">
    <a href="#"><i class="fa fa-user-o"></i>
    <button onclick="location.href='techProfile.php'"><i class="fa fa-caret-down"></i></button>
                    <br> <?php
                $_SESSION['username'];
                ?>
                    <?php echo "{$_SESSION['username']}" ?>
            </a>
            <a href="Technicianhomepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="100px" height="100px" style="color: #000c66;"></a>
  </div>
  <div class="header" >
    <h1 style="font-family: arial;">Wood Street Academy</h1>
  </div>
  <div class="navbar">
    <a href="techjobs.php">Allocated jobs</a>
    <a href="logout.php">Logout</a>
  </div>
  </div>
  <!--added for functional purposes-->
  <div class="main" >
        <h2>Welcome to the Wood Street Academy PC Repairs department!</h2>
        <h5>Our friendly staff is excited to help you with all your needs.</h5>
<div>
  <div class="main" >
        <h2>Welcome to the Wood Street Academy PC Repairs department!</h2>
        <h5>Our friendly staff is excited to help you with all your needs.</h5>
</div>
  <div>
    <h3>
    <div class="main">
    <h1><?php
              
              $_SESSION['username'];
              ?>
             <strong>Welcome Back</strong>  <?php echo "{$_SESSION['username']}" ?></h1>
  </div>

  <button onclick="topFunction()" id="button" title="top">Top</button>
  </div>
  <div>
  <div class="footer2" >
    <div class="copyrightsentence" style="color: white;">
      <small><i class="fa fa-copyright"></i>
        2022. All Rights Reserved. Proudly created by Fantastic Four.
        <a href="termsandpolicies" style="color: white;">Terms and Policies</a>
        Last modified: 24 August 2022</small>
    </div>
  </div>
  <script>

//back to top button
var mybutton = document.getElementById("button");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
  </script>
</body>

</html>