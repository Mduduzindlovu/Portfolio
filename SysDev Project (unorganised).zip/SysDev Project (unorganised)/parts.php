<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order parts</title>
</head>

<body>
    <?php
    // add the crrdentials from the database
    require_once("config.php");
    //request the data values from the form
    $nameofpart = $_REQUEST['nameofpart'];
    $technicianCode=$_SESSION['id'];
    
  
    //establish connection to the database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to the database");
    //store the query and run it
    /* $query= "INSERT INTO fantasticfour.orderparts (NameOfPart, SupplierOfPart) VALUES ('$nameofpart','$supplierofpart')";
$results= mysqli_query($conn, $query) or die("Could not run the query"); */
    // add Tech anf Repair into orderparts
    $qr = "SELECT `repair_job`.`repJB_code` AS rep/* , `technician`.`technicianCode` AS tech */
FROM `fantasticfour`.`repair_job` JOIN `technician` ORDER BY `repair_job`.`repJB_code` DESC/* , `technician`.`technicianCode` Desc; */";
    $result = mysqli_query($conn, $qr) or die("qUERY" . $conn->error);
    $repcode=0;
    while($row=mysqli_fetch_array($result)){
        $repcode=$row['rep'];
      }


    //get brand_Id
    $query= "SELECT idbrand_ID FROM fantasticfour.brandnames where nameofparts='$nameofpart'";
    $results=mysqli_query($conn,$query) or die("could not get the brand ID");
    $brandid= 0;
    while($row=mysqli_fetch_array($results)){
        $brandid=$row['idbrand_ID'];
      }
  
    $qr = "INSERT INTO fantasticfour.orderparts
(`repJBCode`,
`technicianCode`, `NameOfPart`
)
VALUES
($repcode,
'$technicianCode', 
'$nameofpart'
);";
    $result = mysqli_query($conn, $qr) or die("Can't insert into the database" . $conn->error);



    //mysqli_close($conn);

    $qr = "SELECT `orderparts`.`repJBCode` AS rep, `orderparts`.`technicianCode` AS tech
FROM `fantasticfour`.`orderparts` /* JOIN `orderparts` */ ORDER BY `orderparts`.`repJBCode`/* , `technician`.`technicianCode`  */DESC;";
    $result = mysqli_query($conn, $qr) or die("qUERY" . $conn->error);
    $row = mysqli_fetch_array($result);

    $qr = "INSERT INTO fantasticfour.technician_repair(TechnicianCode,RepJB_code,partsCode) VALUES ($technicianCode,$repcode,$brandid)";

    $result = mysqli_query($conn, $qr);

    echo "<h3><strong> The new Part was successfully orderd! </strong></h3>";
    
    $handle = mysqli_query($conn, "SELECT partsCode FROM fantasticfour.orderparts order by partsCode DESC") or die("Could not get the part code");
    $row_rsmyQuery = mysqli_fetch_array($handle);
    $trackingnumber = (int)($row_rsmyQuery['partsCode']);


    // Update the quantity of the part that is ordered by reducing it
    $queryQz = "UPDATE fantasticfour.`brandnames`set Quantity=Quantity-1 WHERE nameofparts = '$nameofpart'";
    $result31 = mysqli_query($conn, $queryQz) or die("could not select data");
    

    echo "
    <h1>Wood Street Academy
       Order Summary</h1>";

    echo "Wood Street Academy
            Drosty Road 
        Makhanda, 6139 <br><br>";

    echo "INVOICE TO:";
    $handle1 = mysqli_query($conn, "SELECT Username FROM fantasticfour.technician where technicianCode=$technicianCode ") or die("Phuck");
    $row_rsmyQuery = mysqli_fetch_array($handle1);
    $techname = ($row_rsmyQuery['Username']);
    echo "<h4>Username:</h4>$techname<br><br>";
    
    echo "<h4>The name of the part(s) placed:</h4>$nameofpart <br><br>";

    echo "THANK YOU! YOUR ODRER WILL BE PROCESSED<br><br>";
    // mysqli_close($conn);
    // for parts here
        echo "<a href=\"partsUpdateForm.php?id=$technicianCode\">Update here</a><br>";
        echo "<a href=\"techjobs.php\">Go Back</a>";
        
    
    ?>
</body>

</html>