<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="homepage.css">
    <title>Completed</title>
</head>
<body>
<!--Icons at the top of the page-->
<div class="icon-bar">
    <a href="managerhomepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="90px" height="90px"></a>
  </div>
  <div class="header">
    <h1 style="font-family: arial;">Wood Street Academy</h1>
  </div>
  <div class="navbar">
  <a href="managergeneratereports.php">Generate Reports</a>
    <a href="managerpartsordered.php">Ordered Parts</a>
    <a href="managerstatus.php">Current status of Repair Jobs</a>
    <a href="partsonhand.php">Amount of parts on hand</a>
    <a href="completed.php">Repairs history of Computing devices</a>
    <a href="managerlogout.php">Logout</a>
  </div>
  </div>
  </div>
    <?php
    
    require_once("config.php");
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");
    $customerCode=0;$computerCode=0;$completedDate='';
$sql ="SELECT * from history_of_repair_jobs ";
$result = mysqli_query($conn,$sql) or die("could not fetch completed Data");
while($row=mysqli_fetch_array($result)){
    $customerCode=$row['customerCode'];
    $computerCode=$row['computerCode'];
    $completedDate=$row['dateTime'];

   
    //getting customer details
$name='';$surname='';$email='';
    $sql2 ="SELECT * from customer where customerCode=$customerCode ";
    $result2 = mysqli_query($conn,$sql2) or die("could not fetch completed Data");
    while($row=mysqli_fetch_array($result2)){
        $name=$row['Firstname'];
        $surname=$row['Lastname'];
        $email=$row['Email'];
        
    // getting computer details
    $device='';$description='';$datebooked='';
        $sql3 ="SELECT * from computers where computerCode=$computerCode ";
        $result3 = mysqli_query($conn,$sql3) or die("could not fetch completed Data");
        while($row=mysqli_fetch_array($result3)){
            $device=$row['deviceName'];
            $description=$row['description'];
            $datebooked=$row['Bookin_date'];
          }
            echo"<div class=\"container\">
            <h2>Customer Details</h2>
            <p>$name  $surname</>
            <p>$email<p>
            <h2>Computer Details</h2>
            <p> $device</p>
            <h5>Description : $description </h5>
            <p>Booked in Date : $datebooked</p>
            <p>Completed Date :  $completedDate</p>
            <strong><p>Status : Completed</p></strong>
            </div>";
            
    }}
    ?>
        <style>
          h2 {text-align: center;}
          h3 {text-align: center;}
          h4 {text-align: center;}
          h5 {text-align: center;}
          p {text-align: center;} 

        .container{
    display: flex;
    
    justify-content: space-around;
    flex-direction: column;
    border: 1px ;
  padding: 10px;
  box-shadow: 5px 8px #edebeb;
  margin-top: 20px;
}
    </style>
</body>
</html>