<?php
session_start()
?>
<?php
//collect the data from the form 
$id = $_REQUEST['id'];
//what form? 21/09
/* $techdescript = $_REQUEST['DescriptionOfthefault']; */
//connect to the database
require_once("config.php");
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");
$query = "SELECT DescriptionOfthefault FROM fantasticfour.repair_job WHERE repJB_code = $id";
$result = mysqli_query($conn, $query) or die("qUERY1" . $conn->error);
//output the null description box
while ($row = mysqli_fetch_array($result)) {
    //store the details from the form 
    $techdescript=$row['DescriptionOfthefault'];
/*     echo "<strong>DescriptionOfthefault:{$row['DescriptionOfthefault']}<br></strong>"; */
}
echo "$techdescript";


//End that little snippet  
//  echo"</table>"; 

mysqli_close($conn);
?>
<form action="REPAIRJOBedit2.php" method="POST">
    <h1>Edit the fault description</h1>
    <label for="Description of fault"><strong>Description of fault:</strong><label><br>
            <input type="text" name="DescriptionOfthefault" id="DescriptionOfthefault" value="<?php echo $techdescript ?>"
                required><br>
            <input type="hidden" name="id" value="<?php echo $id ?>"><br>
            <input type="submit" name="submit" value="Edit Record">
</form>
