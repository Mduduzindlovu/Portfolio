<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Wood Street Academy</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    * {
      box-sizing: border-box;
    }

    /* Style the body */
    body {
      font-family: Arial, Helvetica, sans-serif;
      margin: 0;
    }
    /* freeze container*/
    .container1{
      position: fixed;
      width: 100%;
      z-index: 1;
      transition: 0.3s;

    }
    /* Header*/
    .header {
      /* youll change it here */
      padding: 2px; 
      text-align: center;
      background: #050a30;
      color: #ffd285;
      width: 100%;
      z-index: 1;

    }

    /* Increase the font size of the heading */
    .header h1 {
      font-size: 40px;
    }

    /* Style the top navigation bar */
    .navbar {
      overflow: hidden;
      background-color: #000c66;
      width: 100%;
    }

    /* Style the navigation bar links */
    .navbar a {
      float: left;
      display: block;
      color: white;
      text-align: center;
      padding: 14px 20px;
      text-decoration: none;
    }

    /* Right-aligned link */
    .navbar a.right {
      float: right;
    }

    /* Change color on hover */
    .navbar a:hover {
      background-color: #050a30;
      color: #ffd285;
    }
    /* Main column */
    .main {
      -ms-flex: 70%;
      /* IE10 */
      flex: 70%;
      background-color: white;
      padding-top: 250px;
    }

    /* Fake image, just for this example */
    .fakeimg {
      background-color: #aaa;
      width: 100%;
      padding: 20px;
    }

    /* Footer */
    .footer {
      padding: 10px;
      align-content: center;
      background: #050a30;
      border-radius: 5px;
    }

    /* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
    @media screen and (max-width: 700px) {
      .row {
        flex-direction: column;
      }
    }

    /* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
    @media screen and (max-width: 400px) {
      .navbar a {
        float: none;
        width: 100%;
      }
    }


    /* styling for the icons at the top*/
    body {
      margin: 0;
    }

    .icon-bar {
      width: 100%;
      background-color: #050a30;
      overflow: auto;
      z-index: 1;
    }

    .icon-bar a {
      float: right;
      width: 12%;
      text-align: center;
      padding: 9px 0;
      transition: all 0.3s ease;
      color: white;
      font-size: 21px;
    }

    .icon-bar a.split {
      float: left;
    }

    .icon-bar a:hover {
      background-color: #000c66;
    }

    .active {
      background-color: #050a30;
    }

    /*css for the footer */
    .repairs {
      width: 250px;
      float: left;

    }

    .repairs a {
      background-color: #050a30;
      color: whitesmoke;
      display: block;
      padding: 9px;
      text-decoration: none;
    }

    .repairs a:hover {
      background-color: #000c66;
      color: #ffd285;
    }

    .repairs a.active {
      background-color: #050a30;
      color: white;
    }

    .policies {
      width: 250px;
      float: left;

    }

    .policies a {
      background-color: #050a30;
      color: whitesmoke;
      display: block;
      padding: 9px;
      text-decoration: none;
    }

    .policies a:hover {
      background-color: #000c66;
      color: #ffd285;
    }

    .policies a.active {
      background-color: #050a30;
      color: white;
    }

    .aboutus {
      width: 250px;
      float: left;

    }

    .aboutus a {
      background-color: #050a30;
      color: whitesmoke;
      display: block;
      padding: 9px;
      text-decoration: none;
    }

    .aboutus a:hover {
      background-color: #000c66;
      color: #ffd285;
    }

    .aboutus a.active {
      background-color: #050a30;
      color: white;
    }

    .chatwithus {
      width: 250px;
      float: left;

    }

    .chatwithus a {
      background-color: #050a30;
      color: whitesmoke;
      display: block;
      padding: 9px;
      text-decoration: none;
    }

    .chatwithus a:hover {
      background-color: #000c66;
      color: #ffd285;
    }

    .chatwithus a.active {
      background-color: #050a30;
      color: white;
    }

    .footer1 {
      background-color: #050a30;
      height: 200px;
      padding: 10px;

    }

    .footer2 {
      background-color: #050a30;
      height: 50px;
    }

    .copyrightsentence {
      float: left;
      color: whitesmoke;
    }

    /* Slideshow container for images*/
    * {
      box-sizing: border-box
    }
    /* to scroll image under the fixed bar*/
    header
{
    z-index: 99;
}

    /* Slideshow container */
    .slideshow-container {
      max-width: 100%;
      position: relative;
      margin: auto;
  
    }

    /* Hide the images by default */
    .mySlides {
      display: none;
    }

    /* Next & previous buttons */
    .prev,
    .next {
      cursor: pointer;
      position: absolute;
      top: 50%;
      width: auto;
      margin-top: -22px;
      padding: 16px;
      color: whitesmoke;
      font-weight: bold;
      font-size: 18px;
      transition: 0.6s ease;
      border-radius: 0 3px 3px 0;
      user-select: none;
    }

    /* Position the "next button" to the right */
    .next {
      right: 0;
      border-radius: 3px 0 0 3px;
    }

    /* On hover, add a black background color with a little bit see-through */
    .prev:hover,
    .next:hover {
      background-color: darkgrey;
    }


    /* Number text (1/3 etc) */
    .numbertext {
      color: #f2f2f2;
      font-size: 12px;
      padding: 8px 12px;
      position: absolute;
      top: 0;
    }

    /* The dots/bullets/indicators */
    .dot {
      cursor: pointer;
      height: 15px;
      width: 15px;
      margin: 0 2px;
      background-color: #bbb;
      border-radius: 50%;
      display: inline-block;
      transition: background-color 0.6s ease;
    }

    .active,
    .dot:hover {
      background-color: #717171;
    }

    /* Fading animation */
    .fade {
      animation-name: fade;
      animation-duration: 1.5s;
      opacity: 0.6;
    }

    @keyframes fade {
      from {
        opacity: .4
      }

      to {
        opacity: 1
      }
    }
    /*styling for back to top */
    #button {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: #000c66;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#button:hover {
  background-color: #ffd285;
}
/* styling for the lsit of aims*/
ul  {
  list-style-image: url('images HOMEPAGE/maintenance-repair-service-svgrepo-com.svg');
}
/*styling for the inputs*/
.container{
  display: flex; 
  flex-direction: column;
  border: 1px ;
  padding: 10px;
  box-shadow: 5px 8px #edebeb;
  margin-top: 20px;
}
</style>
</head>
<body>
  </style>
</head>

<body>
  <!--container for icons, header and navbar-->
  <div class="container1">
  <!--Icons at the top of the page-->
  <div class="icon-bar">
    <a href="#"><i class="fa fa-user-o"></i><br> <?php
                
                $_SESSION['username'];
                ?>
                    <?php echo "{$_SESSION['username']}" ?>
            </a>
    <a href="adminhomepage.php" class="split" style="color: #050a30;"><img src="images HOMEPAGE/Logo-removebg-preview.png" width="90px" height="90px" style="color: #050a30;"></a>
  </div>
  <div class="header">
    <h1 style="font-family: arial;">Wood Street Academy</h1>
  </div>
  <div class="navbar">
    <a href="allocateRepairJobs.php">Allocate jobs</a>
    <!-- <a href="AdminBooking.php">Create Repair Job</a> -->
    <a href="Adminlogout.php">Logout</a>
  </div>
  </div>
  <!--added for functional purposes-->
  <div class="main" >


<h3><?php
              
              $_SESSION['username'];
              ?>
             <h1 style="text-align: center;">Welcome Back  <?php echo "{$_SESSION['username']}" ?></h1>
             <h2 style="text-align: center;">Here is a summary of the completed jobs.</h2>

             <?php
    
    require_once("config.php");
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");
    $customerCode=0;$computerCode=0;$completedDate='';
$sql ="SELECT * from history_of_repair_jobs ";
$result = mysqli_query($conn,$sql) or die("could not fetch completed Data");
while($row=mysqli_fetch_array($result)){
    $customerCode=$row['customerCode'];
    $computerCode=$row['computerCode'];
    $completedDate=$row['dateTime'];

   
    //getting customer details
$name='';$surname='';$email='';
    $sql2 ="SELECT * from customer where customerCode=$customerCode ";
    $result2 = mysqli_query($conn,$sql2) or die("could not fetch completed Data");
    while($row=mysqli_fetch_array($result2)){
        $name=$row['Firstname'];
        $surname=$row['Lastname'];
        $email=$row['Email'];
        
    // getting computer details
    $device='';$description='';$datebooked='';
        $sql3 ="SELECT * from computers where computerCode=$computerCode ";
        $result3 = mysqli_query($conn,$sql3) or die("could not fetch completed Data");
        while($row=mysqli_fetch_array($result3)){
            $device=$row['deviceName'];
            $description=$row['description'];
            $datebooked=$row['Bookin_date'];
          echo "<div class=\"container\">";
            echo "<h3>Customer Details</h3>";
            echo "<h3>Customer Name :$name  $surname</h3>";
            echo "<h4>Email : $email</h4>";
            echo "<h3>Computer Details</h3>";
            echo "<h4>Computer Name :  $device</h4>";
            echo "<h5>Description : $description </h5>";
            echo "<hp>Booked in Date : $datebooked</p>";
            echo "<p>Completed Date :  $completedDate</p>";
            echo "<h5>Status : Completed </h5>";
            echo "</div>";


            }
    }}
    ?>
  <button onclick="topFunction()" id="button" title="top">Top</button>
  </div>
 
  <div class="footer2">
    <div class="copyrightsentence">
      <small><i class="fa fa-copyright"></i>
        2022. All Rights Reserved. Proudly created by Fantastic Four.
        <a href="termsandpolicies" style="color: whitesmoke;">Terms and Policies</a>
        Last modified: 24 August 2022</small>
    </div>
  </div>
  </body>
<script>
  //for back to top button
  let mybutton = document.getElementById("button");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}
</script>
</html>