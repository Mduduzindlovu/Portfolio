<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Wood Street Academy</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="homepage.css">
</head>

<body>
  <!--Icons at the top of the page-->
  <div class="icon-bar">
    <a href="#"><i class="fa fa-user-o"></i>
                    <br> <?php
                
                $_SESSION['username'];
                ?>
                    <?php echo "{$_SESSION['username']}" ?>
            </a>
    <a href="managerhomepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="90px" height="90px"></a>
  </div>
  <div class="header">
    <h1 style="font-family: arial;">Wood Street Academy</h1>
  </div>
  <div class="navbar">
  <a href="managergeneratereports.php">Generate Reports</a>
    <a href="managerpartsordered.php">Ordered Parts</a>
    <a href="managerstatus.php">Current status of Repair Jobs</a>
    <a href="partsonhand.php">Total amount of parts on hand</a>
    <a href="completed.php">Repairs history</a>
    <a href="managerlogout.php">Logout</a>
  </div>
  </div>
  </div>
</ul>
<h3><?php
              
              $_SESSION['username'];
              ?>
             <strong>Welcome Back</strong>  <?php echo "{$_SESSION['username']}" ?></h3>
  <button onclick="topFunction()" id="button" title="top">Top</button>
  </div>
  <div id="columnchart" style="width: 900px; height: 500px;"></div>
  </div>
  <div class="footer2">
    <div class="copyrightsentence" style="color: whitesmoke;">
      <small><i class="fa fa-copyright" ></i>
        2022. All Rights Reserved. Proudly created by Fantastic Four.
        <a href="termsandpolicies" style="color: whitesmoke;"> Terms and Policies.</a>
        Last modified: 24 August 2022</small>
    </div>
  </div>
  </body>

</html>