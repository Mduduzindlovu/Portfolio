<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $cuscode = $_REQUEST['cusID'];
    $fname = $_REQUEST['Fname'];
    $lname = $_REQUEST['Lname'];
    $pas  = $_REQUEST['Password'];
    $username = $_REQUEST['username'];
    $email = $_REQUEST['Email'];
    $phoneNumber = $_REQUEST['Phone'];


    require_once("config.php");
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");

    // $CustomersID = 0;
    // while($row = mysqli_fetch_array($res)){
    //     $CustomersID=$row['custormerCode'];
    //    }
    $query = "UPDATE fantasticfour.customer SET Firstname ='$fname',Lastname ='$lname',Password ='$pas',
    Username ='$username',Email = '$email',phoneNumber = '$phoneNumber'
                    WHERE CustomerCode =$cuscode";


    $result = mysqli_query($conn, $query) or die("qUERY1" . $conn->error);
    echo "<script> alert(\"Your profile has been Updated Successfully\")</script>";
    // (header("Location: Register.php")); judi check out this line
    

    mysqli_close($conn);

    
    //$result2 = mysqli_query($conn,$query2) or die("QUERY!")

    ?>
</body>

</html>