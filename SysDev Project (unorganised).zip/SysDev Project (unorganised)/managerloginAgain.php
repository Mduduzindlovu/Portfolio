<!DOCTYPE html>
  <html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
      body {
        font-family: Arial, Helvetica, sans-serif;
      }
      
      * {
        box-sizing: border-box;
      }
      
      /* style the container */
      .container {
        position: relative;
        border-radius: 5px;
        background-color: #050a30;
        padding: 20px 20px 30px 20px;
        float: center;
        display: flex;
      align-items: center;
      justify-content: center;
      } 
      
      /* style inputs and link buttons */
      input,
      .btn {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 4px;
        margin: 5px 0;
        opacity: 0.85;
        display: inline-block;
        font-size: 17px;
        line-height: 20px;
        text-decoration: none; /* remove underline from anchors */
      }
      
      input:hover,
      .btn:hover {
        opacity: 1;
      }
      
      
      
      /* style the submit button */
      input[type=submit] {
        background-color: #000c66;
        color: white;
        cursor: pointer;
      }
      
      input[type=submit]:hover {
        background-color: #000c66;
      }
      .btn:hover{
        background-color: #000c66;
      }
      /* Two-column layout */
      .col {
        width: 50%;
        margin: auto;
        padding: 0 50px;
      }
      
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      
      
      
      
      
      
      /* bottom container */
      .bottom-container {
        text-align: center;
        background-color: #000c66;
        border-radius: 0px 0px 4px 4px;
      }
      
      /* Responsive layout - when the screen is less than 650px wide, make the two columns stack on top of each other instead of next to each other */
      @media screen and (max-width: 650px) {
        .col {
          width: 100%;
          margin-top: 0;
        }
        /* hide the vertical line */
        .vl {
          display: none;
        }
        /* show the hidden text on small screens */
        .hide-md-lg {
          display: block;
          text-align: center;
        }
      }
      </style>
  </head>
  <body>
    <div class="container">
        <div class="row">
          <h2 style="text-align:center; color: #ffd285; ">Welcome Head of Department To Woodstreet Academy</h2>
          <form action="managerloginAgain.php" method="POST">
          <input type="text" name="username" placeholder="Username" required>
          <input type="password" name="password" placeholder="Password" pattern="[x][0-9]{4}"
            title="Must start password with an 'X' followed by 4 numbers" required>
          <input type="submit" name="submit" value="Login">
        </div>
    </div>
    <?php
    if(isset($_REQUEST['submit'])){
session_start();
//store the values 
$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
//check if the password matches
if ($username=="n.phisher" && $password=="x1570" ){
  //set session variable to allow access to webpages
    $_SESSION['access']= "yes";
    $_SESSION['username'] = $username;
    //direct to homepage
    header("Location: managerhomepage.php");
}
 else {
  echo "<p style=\"color: red\"> <strong>ERROR Incorrect Username or Password, Please try again</strong></p>";
}; 
}
?>

    </form>
    </div>

    <div class="bottom-container">
      <div class="row">
        <div class="col">
          <a href="forgotPass.html" style="color:white" class="btn">Forgot password?</a>
        </div>
      </div>
    </div>
  </body>

  </html>