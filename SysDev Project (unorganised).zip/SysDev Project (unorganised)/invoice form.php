<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice form</title>
</head>

<body>
    <?php
    // add the crrdentials from the database
    require_once("config.php");

    //request the data values from the form
    $invoicename = $_REQUEST['username'];
    // $trackingnumber = $_POST['trackingNumber'];
    $description = $_POST['description'];
    $invoicedate = $_POST['date'];

    //establish connection to the database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to the database");

    $handle = mysqli_query($conn, "SELECT repJB_code FROM fantasticfour.repair_job /* where Username ='$username' */") or die("Phuck");
    $row_rsmyQuery = mysqli_fetch_assoc($handle);
    $trackingnumber = (int)($row_rsmyQuery['repJB_code']);

    /*  // Echo out the repjobcode as the tracking number
    $qrinvoice = "SELECT `repair job`.`repJB_code` AS trackingNumber
             FROM `fantasticfour`.`repair job`ORDER BY `repair job`.`repJB_code` DESC";
    $result = mysqli_query($conn, $qr) or die("qUERY" . $conn->error);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn); */

    echo "
    <h1>Wood Street Academy
        Invoice Form </h1>";

    echo "Wood Street Academy
            Drosty Road 
        Makhanda, 6139 <br><br>";

    echo "<h4>Username:</h4>$invoicename <br><br>";

    echo "<h4>Tracking Number:</h4>$trackingnumber <br><br>";

    echo "<h4>Description:</h4>$description <br><br>";

    echo "<h4>Invoice Date:</h4>$invoicedate <br><br>";


    echo "Amount: <br><br>";


    echo "Quantity: <br><br>";



    echo "TOTAL ZAR:R3000 <br><br>";



    ?>


</body>

</html>