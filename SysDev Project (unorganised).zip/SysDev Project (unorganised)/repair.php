<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $datetime= $_REQUEST['date'];
    $Status = $_REQUEST['Status'];
    $description= $_REQUEST['description'];
    require_once("config.php");
    // make connection to database 
    $conn = mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE)
    or die ("<h3><p style = \"color: red\"> Could not connect to the database!</p></h3>");
    // issue query instructions 
    
    $query = "INSERT INTO fantasticfour.repair job ('dateTime','StatusOfrepair','description')
                VALUES('$datetime',' $Status','$CustomerID','$description')";
    $result = mysqli_query($conn,$query) or die ("<h3><p style =\" color:red\"> Could not add Repair </p></h3>");

// insert into the technician repair table//

/* $qr = "SELECT `orderparts`.`repJBCode` AS rep, `orderparts`.`technicianCode` AS tech
FROM `fantasticfour`.`orderparts` */ /* JOIN `orderparts`  ORDER BY `orderparts`.`repJBCode`/* , `technician`.`technicianCode`*/  ;

$qr1="SELECT `fantasticfour`.`repJB_code`AS rep, from `fantasticfour`.`repair_job` WHERE 'repJB_code' = '75' DESC ";
$result2 = mysqli_query($conn,$qr1) or die("qUERY".$conn->error);
$row = mysqli_fetch_array($result2);
 /* $row = mysqli_fetch_array($result2); */

/* while($row)
{ */
$qr55 = "INSERT INTO `fantasticfour`.`technician_repair`
(`RepJB_code`)
VALUES
('{$row['repJB_code']}');";



 $qr55 = "INSERT INTO `fantasticfour`.`technician_repair`
(`RepJB_code`)
 VALUES
 ({$row['rep']});";

$result = mysqli_query($conn,$qr2) ;
//close the connection to database 
   mysqli_close($conn);
// display message to confirm the data was instered 
echo "<h3> The new repair was added! </h3>";


    
    
    
    
    ?>
</body>
</html>