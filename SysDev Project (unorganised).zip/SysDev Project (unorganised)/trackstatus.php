<?php
session_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="homepage.css">
  </head>
<head>
<style>
  /*centre the actual page content */
.mydiv{
text-align: center;
  }
  </style>
</head>
<body>

        <!--Icons at the top of the page-->
        <div class="icon-bar">
            <a href="Homepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="100px" height="100px" style="color: #000c66;"></a>
        </div>
  
<div class="navbar">
          <a href="Homepage.php">Home</a>
          <a href="MakeABooking.php">Make a booking</a>
          <a href="trackstatus.php">Track status</a>
          <a href="Systemdevproject pictures\General Repair prices.html"> General Prices</a>
          <a href="aboutus.html">About us</a>
          <a href="logout.php">Logout</a>
      </div>
  </div>
<form action="statustrack.php" method="POST">

<h2>Wood Street Academy Tracking status online</h2>

<div class="myDiv">
  <br>

  <input type="text" name="trackingNumber" maxlength="30" size="40" id="trackingNumber" placeholder="Enter tracking number" required> 
 
  <input type="submit" name="submit" size="6" id="submit" value="Track">
  <br>
  <br>
</div>
<br>
<br>
</form>
<div class="footer1">
          <div class="repairs">
              <h5>Repairs</h5>
              <a href="#">General pricing</a>
              <a href="FAQ.html">Frequently asked questions</a>
          </div>
          <div class="policies">
              <h5>Policies<h5>
                      <a href="privacypolicy.html">Privacy policy</a>
                      <a href="Termsandconditions.html">Terms and Conditions</a>
          </div>
          <div class="aboutus">
              <a href="aboutus.html">About us</a>
              <a
                  href="https://www.google.com/maps/dir/-33.3106284,26.5255944/rhodes+university/@-33.3119349,26.5102447,15z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x1e645dd0c6d4fc47:0x9982445ffb8737af!2m2!1d26.5163135!2d-33.3135911">Our
                  location</a>
          </div>
      </div>
        <div class="footer2">
          <div class="copyrightsentence">
              <small><i class="fa fa-copyright"></i>
                  2022. All Rights Reserved. Proudly created by Fantastic Four.
                  <a href="termsandpolicies">Terms and Policies</a>
                  Last modified: 24 August 2022</small>
          </div>
</body>
</html>
