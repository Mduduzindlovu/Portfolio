<html>
   <head>
<style>
.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>
</head>
<body>
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>Deleted!</strong> Repair Job has been removed.

</div>
<?php
session_start()
?>
<?php
//store id 
if(isset($_GET['id'])){
   $repCode = $_REQUEST['id'];
   $customerCode=$_REQUEST['customerCode'];
   $computercode=$_REQUEST['computerCode'];

   //import database credentials
   require_once("config.php");
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not establish a connection");

    //get description 
    $query111="SELECT customer_portal from fantasticfour.repair_job where fantasticfour.repair_job.repJB_code=$repCode";
    $result11= mysqli_query($conn, $query111) or die('Could not get the description');
    $desc="";
    while($row=mysqli_fetch_array($result11)){
      $desc=$row['customer_portal'];
    }

 

// add to history
$query2="INSERT into history_of_repair_jobs(repJB_code,customerCode,computerCode,StatusOfrepair) 
VALUES($repCode,$customerCode,$computercode,'Completed')";
   $result2= mysqli_query($conn, $query2) or die('ERROR! Could not enter into history table');


   //issue query
   $query="DELETE from fantasticfour.repair_job where fantasticfour.repair_job.repJB_code=$repCode";
   $result= mysqli_query($conn, $query) or die('ERROR! Could not delete the entry');

   $query1="DELETE from tech_repair where RepairCode=$repCode";
   $result1= mysqli_query($conn, $query1) or die('ERROR! Could not delete from Tech repair table');
   header("Location:REPAIRJOBdelete.php") ;


}
?>
</body>
</html>