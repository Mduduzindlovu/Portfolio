<?php
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technician jobs</title>
</head>
<body>
    <div>
        <div class="icon-bar">
        <a href="Technicianhomepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="100px" height="100px" style="color: #000c66;"></a>
    <div class="navbar" class="split">
            <a href="techjobs.php">Allocated jobs</a>
            <a href="Repairjob1.php"> Repair jobs</a>
            <a href="updateTechStatus.php">Progress status </a>
            <a href="TechnicianLogout.php">Logout</a>
        </div>
        </div>
    </div>

    <?php
require_once("config.php");
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to the database");

$id = $_SESSION['id'];
$query = "SELECT * FROM fantasticfour.tech_repair WHERE TechnicianCode = '$id'"; 
$result =mysqli_query($conn,$query) or die("Could not execute the query...");
$job=0;


while($row=mysqli_fetch_array($result)){
    $job=$row['RepairCode'];

    $customerCode=0;
    $message = "";
    $query1 = "SELECT customerCode,computerCode,customer_portal FROM fantasticfour.repair_job WHERE repJB_code = '$job'";
    $result1 = mysqli_query($conn,$query1) or die("Could not execute the query1...");
    while ($row=mysqli_fetch_array($result1)){
            $customerCode=$row['customerCode'];
            $computerCode= $row['computerCode'];
            $message=$row['customer_portal'];
    
            $queryQb = "SELECT Firstname,Lastname  FROM fantasticfour.`customer` WHERE customerCode = $customerCode";
            $result13 = mysqli_query($conn, $queryQb) or die("could not select data");
            $name="";
            $surname="";
            while ($row = mysqli_fetch_array($result13) ) {
                $name=$row['Firstname'];
                $surname=$row['Lastname'];
            }

         
            $queryQbc = "SELECT deviceName  FROM fantasticfour.`computers` WHERE computerCode = $computerCode";
            $result113 = mysqli_query($conn, $queryQbc) or die("could not select data");
            $device="";
            while ($row = mysqli_fetch_array($result113) ) {
                $device=$row['deviceName'];
               
            }
/* 
    echo"<div class=\"container\">
    <div class=\"details\">
   <p>The Repair Job Code is {$job}</p>
    <p>Customer Name :{$name} {$surname} </p>
    <p>Model:  $device</p>
    <p><strong>Message From Customer : </strong></p>
    <p>$message</p>
    </div>

    <div class=\"buttons\">
         <form action=\"parts.php\" method=\"post\">
        <label for=\"nameofpart\"><strong>Name of part: </strong></label><br>
        <select id=\"nameofpart\" name=\"nameofpart\">
            <option value=\"Screen\">Screen</option>
            <option value=\"keyboard\">keyboard</option>
            <option value=\"battery\">battery</option>
            <option value=\"Mouse\">Mouse</option>
            <option value=\"Charger\">Charger</option>
            <option value=\"Power supply\">Power supply</option>
            <option value=\"Hard drive\">Hard driver</option>
            <option value=\"CPU\">CPU</option>
          </select>
        <input type=\"hidden\" name=\"repCode\" value=\"$job \">
        <input type=\"submit\" value=\"Order\"> 
    </form>
    <a href=\"REPAIRJOBdelete.php?id=$job&customerCode=$customerCode&computerCode=$computerCode\"" . "onClick=\"return confirm('Are you sure you want to delete " .  "the job with ID ".$job. "?"."'); window.location.href='techjobs.php';\" value=\"Delete\">Delete</a>
    <form action=\"updateTechStatus.php\" method=\"POST\">
    <input type=\"hidden\" name=\"repCode\" value=\"$job \">
    <input type=\"hidden\" name=\"repCode\" value=\"$job \">
    <input type=\"submit\" name=\"complete\" value=\"Completed\">
    </form></div>

    </div>
</div>";
 */
            echo "
            <div class=\"container\">
             <div class=\"container-preview\">
             <h5  style=\" font-family:  'Source Sans Pro', sans-serif;\"> Repair Job Code : {$job} </h5>
                 <h3  style=\" font-family: 'Poppins', sans-serif;\"> Model :  $device </h3><br>
                 <h6 style=\" font-family: 'Poppins', sans-serif;\">Customer : {$name} {$surname}  </h6>
             </div>
             <div class=\"customer\">
             <h4 style=\"color : grey\">Message from Customer :</h4>
             <h4><a style=\"font-family: 'Source Sans Pro', sans-serif;\">$message</a></h4></div>
               
         
             <div class=\"sandwich\">
             <form action=\"parts.php\" method=\"POST\">
             <input type=\"hidden\" name='hidden' value='repairJobCode'/>
             <div name=\"message\">
             <h4  style=\" font-family: 'Poppins', sans-serif;\"> Order Part</h4>
             </div>
           
         <div class=\"forms\">
         <div class=\"status\">
         <select id=\"nameofpart\" name=\"nameofpart\">
         <option value=\"Screen\">Screen</option>
         <option value=\"keyboard\">keyboard</option>
         <option value=\"battery\">battery</option>
         <option value=\"Mouse\">Mouse</option>
         <option value=\"Charger\">Charger</option>
         <option value=\"Power supply\">Power supply</option>
         <option value=\"Hard drive\">Hard driver</option>
         <option value=\"CPU\">CPU</option>
       </select>
     <input type=\"hidden\" name=\"repCode\" value=\"$job \">
     <input type=\"submit\" id=\"btn\" class=\"order\" value=\"Order\"> 
            
         </div>
         </form><br>
         <a id=\"btn\" href=\"REPAIRJOBdelete.php?id=$job&customerCode=$customerCode&computerCode=$computerCode\"" . "onClick=\"return confirm('Are you sure you want to delete " .  "the job with ID ".$job. "?"."'); window.location.href='techjobs.php';\" value=\"Delete\">Delete</a><br>
        <form action=\"updateTechStatus.php\" method=\"POST\">
             <div class=\"status\">
                 <form >
                 <input type=\"hidden\" name=\"repCode\" value=\"$job \">
                 <input type=\"hidden\" name=\"repCode\" value=\"$job \">
                 <input id=\"btn\" class=\"completed\" type=\"submit\" name=\"complete\" value=\"Completed\">
                 </form>     
             </div>
             </form>
         </div>
             </div>
             </div>
             ";

    
   }}echo"</div>";
mysqli_close($conn);


    ?>
</body>
<style>
    /*styling for the nav bar*/
    .icon-bar {
  width: 100%;
  background-color: #050a30;
  overflow: auto;
  z-index: 1;
}

.icon-bar a {
  width: 15%;
  text-align: center;
  padding: 3px 0;
  transition: all 0.3s ease;
  color: white;
  font-size: 21px;
}

.icon-bar a.split {
  float: left;
}

.icon-bar a:hover {
  background-color: #000c66;
}
.navbar {
  overflow: hidden;
  background-color: #000c66;
  width: 100%;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 9px 5px;
  text-decoration: none;
}

/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #050a30;
  color: #ffd285;
}


 .completed{
        margin-top: 7px;
    }
form{
    margin-top:3px;
    margin-bottom:5px;
    padding: 4px;
}
a{  border-radius: 4px;
    text-decoration: none;
    padding: 8px;
}
.order{
    margin-top: 7px;
    height: 48px;
    margin-left: 4px;
}
.status{
    display: flex;
   
}
.status #btn{

}

 .customer{
  width:190px;
} 
   .body {

font-family: 'Muli', sans-serif;
display: flex;
align-items: center;
justify-content: center;
flex-direction: column;

margin: 0;
}


input[type=text],input[type=email],input[type=password],textarea,select {
width: 100%;
padding: 12px 20px;
margin: 8px 0;
display: inline-block;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
}

.container {
background-color: #fff;
border-radius: 10px;
box-shadow: 0 10px 10px rgba(0, 0, 0, 0.2);
display: flex;
max-width: 100%;
justify-content:space-around;
align-items:center;
overflow: hidden;
margin-top:30px;
margin-left:200px;
width: 80%;
height:265px;
}

.container h6 {
opacity: 0.6;
margin: 0;
letter-spacing: 1px;
text-transform: uppercase;
}

.container h2 {
letter-spacing: 1px;
margin: 10px 0;
}

.container-preview {

color: black;
padding: 30px;
max-width: 200px;
}

.container-preview a {
color: rgb(17, 37, 94);
display: inline-block;
font-size: 12px;
opacity: 0.6;
margin-top: 30px;
text-decoration: none;
}

.container-info {
padding: 30px;
position: relative;
width: 100%;
}

.cid-container {
position: absolute;
top: 30px;
right: 30px;
text-align: right;
width: 150px;
}



input{

  padding:8px 8px;
  border:1px solid grey ;
  border-radius:6%;
  margin-bottom:8px;
}
input[type="text"]:focus{
outline:1px solid grey ;
}
.btn{
  height:32px;
  width:35px;
 
}

.btn:hover{
 
  cursor: pointer;

}

.wrapper{
  margin : 20px 550px;
}
#btn{
 background-color: rgb(137, 125, 190);
  color:black;
  border:none;
  
  font-weight: 300;
}
#btn:hover{
  cursor:pointer;
}
</style>
</html>