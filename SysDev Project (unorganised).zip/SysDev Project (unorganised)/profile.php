<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="homepage.css"> 
    <title>Update information html page. </title>
</head>

<body>
    <!--Icons at the top of the page-->
    <div class="icon-bar">
        <div class="icon-items">
        <a href="Homepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="100px" height="100px" style="color: #000c66;"></a>
            <a href="Homepage.php"><i class="fa fa-home"></i></a>
        </div>

    </div>

    <div class="header">
            <h1 style="font-family: arial; color: #ffd285">Wood Street Academy</h1>
        </div>

    <div class="navbar">
        <a href="MakeABooking.php">Make a booking</a>
        <a href="trackstatus.php">Track status</a>
        <a href="Systemdevproject pictures/General Repair prices.html">Repair Prices</a>
        <a href="aboutus.html">About us</a>
        <a href="logout.php">Logout</a>
    </div>
    <?php ?>

    <!--This is is a whole webpage-->
    <div class="registerbody">
        <?php
        $_SESSION['username']; ?>

        <h1>Welcome Back <?php echo "{$_SESSION['username']}" ?></h1>

        <?php
        require_once("config.php");
        $name = $_SESSION['username'];
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("No");

        $query = "SELECT * FROM fantasticfour.customer WHERE Username = '$name'";
        $result = mysqli_query($conn, $query) or die("could not retrieve data" . $conn->error);

        while ($row = mysqli_fetch_array($result)) {

            echo "
          <form action=\"profileUpdate.php\" method=\"post\">
          <label for=\"Firstname\"><b>Firstname</b></label><br>
          <input type=\"text\" value=\"{$row['Firstname']}\" id=\"Fname\" name=\"Fname\" required><br><br>
            
          <label for=\"Lastname\"><b>Lastname</b></label><br>
          <input type=\"text\" value=\"{$row['Lastname']}\" id=\"Lname\" name=\"Lname\" required><br><br>

          <label for=\"Username\"><b>Username</b></label><br>
          <input type=\"text\" value=\"{$row['Username']}\" id=\"Uname\" name=\"username\" required><br><br>

          <label for=\"Email\"><b>Email</b></label><br>
          <input type=\"email\" value=\"{$row['Email']}\" id=\"Email\" name=\"Email\" required><br><br>

          <label for=\"Psw\"><b>Password</b></label><br>
          <input type=\"password\" id=\"Password\" value=\"{$row['Password']}\" name=\"Password\" pattern=\"[x][0-9]{4}\"
              required><br><br>

          <label for=\"Phone\"><b>Phone</b></label><br>
          <input type=\"number\" id=\"Password\" value=\"{$row['phoneNumber']}\" name=\"Phone\" required><br><br>
          
          <input type=\"hidden\" name=\"cusID\" id=\"cusID\" value=\"{$row['customerCode']}\">
          <input type=\"submit\" value=\"Update\" size=\"30\" ><br>
          </form>
          ";
        }




        ?>

    </div>


    <div class="footer1" style="color: whitesmoke;">
        <div class="repairs" style="color: whitesmoke;">
            <h5 style="color: whitesmoke;">Repairs</h5>
            <a href="Systemdevproject pictures/General Repair prices.html" style="color: whitesmoke;">General pricing</a>
            <a href="FAQ.html" style="color: whitesmoke;">Frequently asked questions</a>
        </div>
        <div class="policies" style="color: whitesmoke;">
            <h5>Policies<h5>
                    <a href="privacypolicy.html" style="color: whitesmoke;">Privacy policy</a>
                    <a href="Termsandconditions.html" style="color: whitesmoke;">Terms and Conditions</a>
        </div>
        <div class="aboutus" style="color: whitesmoke;">
            <a href="aboutus.html" style="color: whitesmoke;">About us</a>
            <a
                href="https://www.google.com/maps/dir/-33.3106284,26.5255944/rhodes+university/@-33.3119349,26.5102447,15z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x1e645dd0c6d4fc47:0x9982445ffb8737af!2m2!1d26.5163135!2d-33.3135911" style="color: whitesmoke;">Our
                location</a>
        </div>
    </div>
    <div class="footer2" style="color: whitesmoke;">
        <div class="copyrightsentence" style="color: whitesmoke;">
            <small><i class="fa fa-copyright"></i>
                2022. All Rights Reserved. Proudly created by Fantastic Four.
                <a href="termsandpolicies" style="color: whitesmoke;">Terms and Policies</a>
                Last modified: 24 August 2022</small>
        </div>
    </div>

</body>

</html>