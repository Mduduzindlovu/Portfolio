<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="homepage.css">
<title>Manager parts ordered summary</title>
<style>
table{
    border-collapse: collapse;
    width: 90%;
    margin: 35px;
        }
td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: rgba(1, 1, 122, 0.1);
}
tr:hover {
    background-color: #050a30;
    color: whitesmoke;
}
    </style>
</head>
<body>
          <!--Icons at the top of the page-->
  <div class="icon-bar">
    <a href="managerhomepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="90px" height="90px"></a>
  </div>
  <div class="header">
    <h1 style="font-family: arial;">Wood Street Academy</h1>
  </div>
  <div class="navbar">
  <a href="managergeneratereports.php">Generate Reports</a>
    <a href="managerpartsordered.php">Ordered Parts</a>
    <a href="managerstatus.php">Current status of Repair Jobs</a>
    <a href="partsonhand.php">Total amount of parts on hand</a>
    <a href="completed.php">Repairs history</a>
    <a href="managerlogout.php">Logout</a>
  </div>
  </div>
  </div>
    <?php

        // add the crrdentials from the database
        require_once("config.php");
            //establish connection to the database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to the database");
    //store and run the query
    $query= "SELECT partsCode, technicianCode, NameofPart,orderDate FROM fantasticfour.orderparts";
    $results=mysqli_query($conn,$query);
    mysqli_close($conn);
    echo "<h2 style=\"text-align:center\">Summary </h2>";
    echo "<table>";
    echo  "<tr>
            <td>Parts Code</td>
            <td>Technician Code</td>
            <td>Part ordered</td>
            <td>Date</td>
            </tr>";
            while ($row = mysqli_fetch_array($results)) {
                echo "<tr>
            <td>{$row['partsCode']}</td>
            <td>{$row['technicianCode']}</td>
            <td>{$row['NameofPart']}</td>
            <td>{$row['orderDate']}</td>
            </tr>";
            }
        "</table>"
    ?>
</body>
</html>