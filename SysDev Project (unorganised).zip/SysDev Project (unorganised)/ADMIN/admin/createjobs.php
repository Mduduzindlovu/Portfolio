<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
session_start();
// hello
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    
     $fname = $_REQUEST['Fname'];
     $lname = $_REQUEST['Lname'];
    $pas  = $_REQUEST['Password'];
     $username = $_REQUEST['Uname'];
     $email = $_REQUEST['Email'];
     $date = $_REQUEST['date'];
     $nameofdevice = $_REQUEST['deviceName'];
     $phoneNumber = $_REQUEST['Phone'];
     $description = $_REQUEST['description'];
     
require_once("config.php");
$conn= mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or die("No");

$query = "INSERT INTO fantasticfour.customer (Firstname,Lastname,Username,Email,Bookin_date,Password,phoneNumber,deviceName) 
            VALUES ('$fname','$lname','$username','$email','$date' ,'$pas','$phoneNumber','$nameofdevice')";


$result = mysqli_query($conn,$query) or die("qUERY1");
//$result2 = mysqli_query($conn,$query2) or die("QUERY!")

mysqli_close($conn);

require_once("config.php");
$conn= mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or die("No");

$handle = mysqli_query($conn,"SELECT customerCode FROM fantasticfour.customer WHERE Username= '$username'") or die("Phuck");
$row_rsmyQuery = mysqli_fetch_assoc($handle);
$img = (int)($row_rsmyQuery['customerCode']);

$qr = "INSERT INTO fantasticfour.computers (customerCode,deviceName,description) VALUES ('$img','$nameofdevice','$description')";
$result = mysqli_query($conn,$qr) or die("qUERY".$conn->error);

$qr = "SELECT `computers`.`computerCode`,
    `computers`.`customerCode`,
    `computers`.`deviceName`
FROM `fantasticfour`.`computers` ORDER BY `computers`.`computerCode` Desc;";
$result = mysqli_query($conn,$qr) or die("qUERY".$conn->error);
$row = mysqli_fetch_array($result);
$qr = "INSERT INTO `fantasticfour`.`repair_job`
(`customerCode`,
`computerCode`
)
VALUES
({$row['customerCode']},
{$row['computerCode']}
);";
$result = mysqli_query($conn,$qr) or die("qUERY".$conn->error);

mysqli_close($conn);

echo "<h3> The new Customer was added successfully! </h3>";
?>
</body>
</html>  
</body>
</html>