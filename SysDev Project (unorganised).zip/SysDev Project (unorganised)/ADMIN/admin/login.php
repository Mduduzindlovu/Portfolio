<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
session_start(); 
$username = $_POST['username'];
$pass = $_POST['password'];
$hash = password_hash($pass,PASSWORD_DEFAULT);
$_SESSION['id'] = 0;
require_once("config.php");

$conn= mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or die("No");

$sql ="SELECT Username,Password,technicianCode  FROM fantasticfour.technician WHERE Username='$username' AND Password='$pass'";
$result = mysqli_query($conn,$sql);
$database_password = "" ;
$id = 0;
$username_ = "";
echo "$database_password";
while($row = mysqli_fetch_array($result)){
    $database_password= $row['Password'];
    $id = $row['technicianCode'];
    $username_ =$row['Username'];
 
}
echo "$database_password";
echo "$username_";
if ($pass==$database_password && $username==$username_ ){
    $_SESSION['id']= $id;
    $_SESSION['username'] = $username;
    header("Location: Homepage.php");
    echo "user exists";
}
 else if($pass!=$database_password) {
   
    echo '<script type="text/javascript">';
    echo ' alert("You have entered the wrong password, Please try again")';  //not showing an alert box.
    echo '</script>';
    header("Location:login.html");

};  
/* if (isset($check)) {

        // $_SESSION['access'] = "yes";

        // $_SESSION['username'] = $username;
    
        header("Location: Homepage.html");}

       */
    mysqli_close($conn); 
    ?>
</body>
</html>