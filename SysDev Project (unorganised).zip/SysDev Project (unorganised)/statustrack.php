<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<style>
         /*header section*/
         * {
  box-sizing: border-box;
}
/* Style the body */
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}
/* Style the top navigation bar */
.navbar {
  overflow: hidden;
  background-color: #000c66;
  width: 100%;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}

/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #050a30;
  color: #ffd285;
}



/* Footer */
.footer {
  padding: 10px;
  align-content: center;
  background: #050a30;
  border-radius: 5px;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width: 100%;
  }
}

</style>
</head>
<body>
<div class="navbar">
          <a href="MakeABooking.php">Make a booking</a>
          <a href="trackstatus.php">Track status</a>
          <a href="Systemdevproject pictures\General Repair prices.html"> General Repair Prices</a>
          <a href="">Make a Payment</a>
          <a href="aboutus.html">About us</a>
          <a href="logout.php">Logout</a>
      </div>
  </div>

<h2>Wood Street Academy Tracking status online</h2><br>

<?php
 
require_once("config.php");
if(isset($_REQUEST['submit'])){
  $status_id = $_REQUEST['trackingNumber'];
  $_SESSION['tracking']= $status_id;
  $img=0;
  $conn= mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or die("No");

  $qr = mysqli_query($conn,"SELECT * from fantasticfour.repair_job where repJB_code = '$status_id'") or die("die");

  $row_rsmyQuery = mysqli_fetch_assoc($qr);
  $img = (int)($row_rsmyQuery['StatusOfrepair']);
  
  mysqli_close($conn);
}
?>
<form action="statustrack.php" method="POST">

<label for="file">
  <?php
$feedback = "In progress";
if($img==100){
  $feedback = "<strong> Repair Job Complete </strong> ";
}
else if ($img ==50){
  $feedback = "<strong>Repair Job in Progress...</strong>";
}
else {$feedback = "<strong> Repair Job Booked-In </strong>";} 
echo $feedback; 
?>
</label> <progress name="file" id="file" max="100" value=<?php echo $img ?>> </progress><?php echo $img;?>% 
</form>
<form action="message.php"  method="POST">
<label for="">Send your Technician a Message</label><br>
<textarea name="message" id="" cols="20" rows="10"></textarea>
<input type="submit" name="send"/>
</form>
</body>


</html>
