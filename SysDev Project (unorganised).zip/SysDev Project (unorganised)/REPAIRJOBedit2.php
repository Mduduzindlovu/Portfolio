<?php
session_start()
?>
<?php
require_once("config.php");
$id = $_REQUEST['id'];
//collect the data from the form 
$techdescript = $_REQUEST['DescriptionOfthefault'];
$conn= mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to your database");
//store and run the query

$query1 = "UPDATE fantasticfour.repair_job SET DescriptionOfthefault = '$techdescript' WHERE repJB_code = $id";
$result = mysqli_query($conn, $query1) or die("qUERY2" . $conn->error);

echo "<p> Its done</p>";

?>