<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
//add creditials from the database
require_once("config.php");
//get the values from the form
$firstname= $_REQUEST['firstname'];
$lastname=$_REQUEST['lastname'];
$username=$_REQUEST['username'];
$email=$_REQUEST['email'];
//establish connection to the database
$conn= mysqli_connect(SERVERNAME,USERNAME,PASSWORD,DATABASE) or die("Could not connect to the database");
//store the query and run it
$query= "INSERT INTO fantasticfour.technician (Firstname, Lastname, Username, Email) VALUES ('$firstname', '$lastname', '$username', '$email')";
$results= mysqli_query($conn, $query) or die("Could not run the query");
//close the connection
mysqli_close($conn);
?>
</body>
</html>