<?php
session_start()
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="homepage.css">
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: Arial;
      padding: 10px;
      background: #f1f1f1;
    }

    /* Header/Blog Title */
    .header {
      padding: 30px;
      text-align: center;
      background-color: #050a30;
      position: relative;
    }

    .header h1 {
      font-size: 50px;
    }

    /* Style the top navigation bar */
    .topnav {
      overflow: hidden;
      background-color:#000c66;
      color: whitesmoke ;

    }

    /* Style the topnav links */
    .topnav a {
      float: left;
      display: block;
      text-align:center;
      padding: 14px 16px;
      text-decoration: none;
    }

    /* Change color on hover */
    .topnav a:hover {
      background-color: #000c60;
      color: #ffd285; 
    }

    .header input[type=text] {
      float: center;
      padding: 6px;
      border: 2px;
      margin-top: 6px;
      margin-right: 16px;
      font-size: 17px;
    }

    /* Create two unequal columns that floats next to each other */
    /* Left column */
    .leftcolumn {
      float: left;
      width: 60%;
    }

    /* Right column */
    .rightcolumn {
      float: right;
      width: 40%;
      /* background-color: #f1f1f1; */
      padding-left: 20px;
    }



    /* Add a card effect for articles */
    .card {
      background-color: white;
      padding: 20px;
      margin-top: 20px;
    }

    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }

    /* for burger nav */
    .sidenav {
      float: left;
      height: 100%;
      width: 0;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: rgb(235, 235, 235);
      overflow-x: hidden;
      transition: 0.5s;
      padding-top: 60px;
    }

    .sidenav a {
      padding: 8px 8px 8px 32px;
      text-decoration: none;
      font-size: 25px;
      color: #000c60;
      display: block;
      transition: 0.3s;
    }

    .sidenav a:hover {
      color: #000c60;
    }

    .sidenav .closebtn {
      position: absolute;
      top: 0;
      right: 25px;
      font-size: 36px;
      margin-left: 50px;
    }

    /* Style inputs with type="text", select elements and textareas */
    input[type=text],
    select,
    textarea {
      width: 100%;
      /* Full width */
      padding: 12px;
      /* Some padding */
      border: 1px solid #ccc;
      /* Gray border */
      border-radius: 4px;
      /* Rounded borders */
      box-sizing: border-box;
      /* Make sure that padding and width stays in place */
      /* margin-top: 6px; /* Add a top margin */
      /* margin-bottom: 16px; Bottom margin */
      /* resize: vertical Allow the user to vertically resize the textarea (not horizontally) */
    }

    /* Style the submit button with a specific background color etc */
    input[type=submit] {
      background-color: #050a30;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    /* When moving the mouse over the submit button, add a darker green color */
    input[type=submit]:hover {
      background-color: #000c60;
    }

    /* Add a background color and some padding around the form */
    .container {
      border-radius: 5px;
      background-color: #050a30;
      color: #ffd285;
      padding: 20px;
    }

    #main {
      transition: margin-left .5s;
      padding: 16px;
      background-color: #050a30;

    }

    @media screen and (max-height: 450px) {
      .sidenav {
        padding-top: 15px;
      }

      .sidenav a {
        font-size: 18px;
      }
    }

    /* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
    @media screen and (max-width: 800px) {

      .leftcolumn,
      .rightcolumn {
        width: 100%;
        padding: 0;
      }
    }

    /* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
    @media screen and (max-width: 400px) {

      .topnav a,
      .header input[type=text] {
        float: none;
        width: 100%;
      }
    }
  </style>
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>
    <!--Icons at the top of the page-->
    <div class="icon-bar">
        <div class="icon-items">
        <a href="Homepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="100px" height="100px" style="color: #000c66;"></a>
            <a href="Homepage.php"><i class="fa fa-home"></i></a>
        </div>

    </div>

    <div class="header">
            <h1 style="font-family: arial; color: #ffd285">Wood Street Academy</h1>
        </div>
    <script>
      function openNav() {
        document.getElementById("mySidenav").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
      }

      function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("main").style.marginLeft = "0";
        document.body.style.backgroundColor = "white";
      }
    </script>

  </div>

  <div class="topnav">
    <a href="Homepage.php" style="color: whitesmoke;">Home</a>
    <a href="MakeABooking.php" style="color: whitesmoke;" >Make a booking</a>
    <a href="statustrack.php" style="color: whitesmoke;">Track status</a>
    <a href="Systemdevproject pictures/General Repair prices.html" style="color: whitesmoke;">General Prices</a>
    <a href="aboutus.html" style="color: whitesmoke;">About us</a>
  </div>

  <div class="row">
    <div class="leftcolumn">
      <div class="card">
        <h2><strong>Book a Repair Job</strong></h2>
        <p>Please fill out the booking form and soon we will contact you to schedule on appointment</p>
        <!-- here goes the form -->
        <div>
        
        </div>
        <div class="container">
          <form action="BOOKING.PHP" method="post">
            <label for="nameofdevice">Device Name </label>
            <select id="nameofdevice" name="nameofdevice">
            <option value="Acer">Acer</option>
              <option value="Apple">Apple</option>
              <option value="Asus">Asus</option>
              <option value="Lenovo">Lenovo</option>
              <option value="HP">HP</option>
              <option value="Toshiba">Toshiba</option>
              <option value="Other">Other</option>
            </select>

            <label for="problem">What is the issue you having </label>
            <select id="problem" name="problem">
              <option value="Screen">Screen</option>
              <option value="battery">Battery</option>
              <option value="keyboard">Keyboard</option>
              <option value="Mouse">Mouse</option>
              <option value="Charger">charger</option>
              <option value="Power Supply">Power Supply</option>
              <option value="CPU">CPU</option>
              <option value="Hard drive">Hard Drive</option>
            </select>
            <label for="description">Give us more detail on your problem</label>
            <textarea id="description" name="description" placeholder="..." style="height:100px"></textarea>
            <label for="date">Date of booking</label>
            <input type="date" name="date" id="date"> <br><br>
            

            <!-- <div class="g-recaptcha" data-sitekey="6Ldbdg0TAAAAAI7KAf72Q6uagbWzWecTeBWmrCpJ"></div> -->
            <input type="submit" value="Submit" style="color: #ffd285;">

          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="footer1" style="color: whitesmoke;">
        <div class="repairs" style="color: whitesmoke;">
            <h5 style="color: whitesmoke;">Repairs</h5>
            <a href="Systemdevproject pictures/General Repair prices.html" style="color: whitesmoke;">General pricing</a>
            <a href="FAQ.html" style="color: whitesmoke;">Frequently asked questions</a>
        </div>
        <div class="policies" style="color: whitesmoke;">
            <h5>Policies<h5>
                    <a href="privacypolicy.html" style="color: whitesmoke;">Privacy policy</a>
                    <a href="Termsandconditions.html" style="color: whitesmoke;">Terms and Conditions</a>
        </div>
        <div class="aboutus" style="color: whitesmoke;">
            <a href="aboutus.html" style="color: whitesmoke;">About us</a>
            <a
                href="https://www.google.com/maps/dir/-33.3106284,26.5255944/rhodes+university/@-33.3119349,26.5102447,15z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x1e645dd0c6d4fc47:0x9982445ffb8737af!2m2!1d26.5163135!2d-33.3135911" style="color: whitesmoke;">Our
                location</a>
        </div>
    </div>
    <div class="footer2" style="color: whitesmoke;">
        <div class="copyrightsentence" style="color: whitesmoke;">
            <small><i class="fa fa-copyright"></i>
                2022. All Rights Reserved. Proudly created by Fantastic Four.
                <a href="termsandpolicies" style="color: whitesmoke;">Terms and Policies</a>
                Last modified: 24 August 2022</small>
        </div>
    </div>
  

</body>

</html>