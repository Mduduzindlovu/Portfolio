<?php
session_start(); 
?>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
        * {
      box-sizing: border-box;
    }
    /*
    form.bones{
      background-color: pink;
      transform: 50%;
    }*/

    /* Style the body */
    body {
      font-family: Arial, Helvetica, sans-serif;
      margin: 0;
    }
    /* freeze container*/
    .container1{
      position: fixed;
      width: 100%;
      z-index: 1;
      transition: 0.3s;

    }
    /* Header*/
    .header {
      /* youll change it here */
      padding: 2px; 
      text-align: center;
      background: #050a30;
      color: #ffd285;
      width: 100%;
      z-index: 1;

    }

    /* Increase the font size of the heading */
    .header h1 {
      font-size: 40px;
    }

    /* Style the top navigation bar */
    .navbar {
      overflow: hidden;
      background-color: #000c66;
      width: 100%;
    }

    /* Style the navigation bar links */
    .navbar a {
      float: left;
      display: block;
      color: white;
      text-align: center;
      padding: 14px 20px;
      text-decoration: none;
    }

    /* Right-aligned link */
    .navbar a.right {
      float: right;
    }

    /* Change color on hover */
    .navbar a:hover {
      background-color: #050a30;
      color: #ffd285;
    }

    /* Column container */
    .row {
      display: -ms-flexbox;
      /* IE10 */
      display: flex;
      -ms-flex-wrap: wrap;
      /* IE10 */
      flex-wrap: wrap;
    }

    /* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
    @media screen and (max-width: 700px) {
      .row {
        flex-direction: column;
      }
    }

    /* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
    @media screen and (max-width: 400px) {
      .navbar a {
        float: none;
        width: 100%;
      }
    }


    /* styling for the icons at the top*/
    body {
      margin: 0;
    }

    .icon-bar {
      width: 100%;
      background-color: #050a30;
      overflow: auto;
      z-index: 1;
    }

    .icon-bar a {
      float: right;
      width: 12%;
      text-align: center;
      padding: 9px 0;
      transition: all 0.3s ease;
      color: white;
      font-size: 21px;
    }

    .icon-bar a.split {
      float: left;
      color: #050a30;
    }

    .icon-bar a:hover {
      background-color: #000c66;
    }

    .active {
      background-color: #050a30;
    }


    /* Fading animation */
    .fade {
      animation-name: fade;
      animation-duration: 1.5s;
      opacity: 0.6;
    }

    @keyframes fade {
      from {
        opacity: .4
      }

      to {
        opacity: 1
      }
    }
    /*styling for back to top */
    #button {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: #050a30;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
  }

  #button:hover {
    background-color: #000c66;
  }
</style>

</head>
<body>
   <!--container for icons, header and navbar-->
   <div class="container1">
  <!--Icons at the top of the page-->
  <div class="icon-bar">
    <a href="#"><i class="fa fa-user-o"></i>
    <button onclick="location.href='techProfile.php'"><i class="fa fa-caret-down"></i></button>
                    <br> <?php
                
                $_SESSION['username'];
                ?>
                    <?php echo "{$_SESSION['username']}" ?>
            </a>
    <a href="adminhomepage.php"><i class="fa fa-home"></i></a>
    <a href="adminhomepage.php" class="split"><img src="images HOMEPAGE/logo-removebg-preview.png" width="90px" height="90px"></a>
  </div>
  <div class="header">
    <h1 style="font-family: arial;">Wood Street Academy</h1>
  </div>
  <div class="navbar">
    <a href="allocateRepairJobs.php">Allocate jobs</a>
    <a href="MakeABooking.php">Create a job</a>
    <a href="Adminlogout.php">Logout</a>
  </div>
  </div>   

  <form class="bones" action="allocateRepairJobs.php" method="POST">
    <label for="Technician">Technician</label><br>
<select  class="form-select" aria-label="Default select example" id="TechnicianCode" name="TechnicianCode"  >
<?php
    require_once("config.php");
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to the database");
    $query="SELECT * FROM fantasticfour.technician";
    $results= mysqli_query($conn,$query);

    $name = ""; 
    $id = 0;
    
    while($row = mysqli_fetch_array($results)){
        $name = $row['Username'];
        $id = $row ['technicianCode'];

        echo "<option value = '$id' > $name </option>";
    }
?> 
</select><br>

<label for="Allocate a repair Job">Allocate a repair Job</label><br>

<select class="form-select" aria-label="Default select example" id="" name="repJB_code">
<?php
    require_once("config.php");
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to the database");
    $query="SELECT * FROM fantasticfour.repair_Job";
    $results= mysqli_query($conn,$query);

    $name = ""; 
    $id = 0;
    
    while($row = mysqli_fetch_array($results)){
       
        $id = $row ['repJB_code'];

        echo "<option value = '$id' > $id </option>";
    }
    
?> 
</select>
<br><br>

<input type="submit" name='submit' value="Allocate">
</form>
<?php

   if(isset($_REQUEST['submit'])){ 
     $namealloca= $_REQUEST['repJB_code'];
     $name=$_REQUEST['TechnicianCode'];
     $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to the database");
    $query="SELECT * FROM fantasticfour.technician where technicianCode=$name";
    $results= mysqli_query($conn,$query) or die("could not  select");
    $name = ""; 
  
    while($row = mysqli_fetch_array($results)){
        $name = $row['Username'];
      }
    echo "Repair Job {$namealloca} was successful allocated to {$name}";
  }   
?> 
<?php

require_once("config.php");
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) or die("Could not connect to the database");


if(isset($_REQUEST['submit'])){
$tech=$_REQUEST['TechnicianCode'];
$repair_code= $_REQUEST['repJB_code'];
$qr = "INSERT INTO tech_repair (TechnicianCode,Repaircode) VALUE ($tech,$repair_code)";
$results= mysqli_query($conn,$qr) or die("ERROR: unable to add under Technician Repair Table"); 

$qr1 = "UPDATE repair_job SET StatusOfrepair=50 where repJB_code=$repair_code";
$results= mysqli_query($conn,$qr1) or die("Could not update the repair job "); 

mysqli_close($conn); 
   }   


?>

</body>





</html>


